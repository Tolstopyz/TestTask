package Helper;

import org.apache.log4j.Logger;
import org.testng.Assert;

public class Error {
   private static final Logger LOG = Logger.getLogger(Error.class);

   public static void autotestError(String message) {
      LOG.error(message);
      ScreenShooter.capturingFullPage();
      Assert.fail(message);
   }
}
