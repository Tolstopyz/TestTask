package Helper;

import DriverBuilder.Driver;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

import static Helper.Elements.waitEnableElement;

public class Helper {

   private static final Logger LOG = Logger.getLogger(Helper.class);

   private static HashMap<String, String> storage;
   private static HashMap<String, HashMap<String, String>> storageNews;

   static {
      storage = new HashMap<>();
      storageNews = new HashMap<>();
   }

   public static void setStorage(String key, String value) {
      storage.put(key, value);
   }

   public static String getStorage(String key) {
      LOG.info("Получаем значение из storage по ключу " + key);
      if (!storage.containsKey(key)) {
         return "";
      }
      return storage.get(key);
   }

   public static void setNews(String newsName, HashMap<String, String> valueNews) {
      storageNews.put(newsName, valueNews);
   }

   public static void getNews(String newsName) {
      storageNews.get(newsName);
   }

   public static void closeTabAndSwitchMainWindow() {
      LOG.info("Проверяем кол-во открытых вкладок");
      if (new ArrayList<>(Driver.getWebDriver().getWindowHandles()).size() != 1) {
         LOG.info("Вкладок больше 1, закрываем одну");
         Driver.getWebDriver().close();
      }
      ArrayList<String> tabs = new ArrayList<>(Driver.getWebDriver().getWindowHandles());
      LOG.info("Кол-во открытых вкладок: " + tabs.size());
      LOG.info("Переключаемся на 0 вкладку");
      Driver.getWebDriver().switchTo().window(tabs.get(0));
   }

   public static String getRandomHeadline() {
      LOG.info("Генерируем рандомный заголовок для новости");
      return String.valueOf(UUID.randomUUID());
   }

   public static String getNameValue(By element) {
      LOG.info("Возвращаем имя элементая через JS");
      JavascriptExecutor jse = (JavascriptExecutor) Driver.getWebDriver();
      return String.valueOf(jse.executeScript("return arguments[0].value;", waitEnableElement(element)));
   }

   public static String getNameValue(WebElement element) {
      LOG.info("Возвращаем имя элементая через JS");
      JavascriptExecutor jse = (JavascriptExecutor) Driver.getWebDriver();
      return String.valueOf(jse.executeScript("return arguments[0].value;", element));
   }
}
