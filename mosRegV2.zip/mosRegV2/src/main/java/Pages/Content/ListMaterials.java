package Pages.Content;

import DriverBuilder.Driver;
import Helper.Props;
import Objects.News;
import Pages.CreateNewNews.MainTab;
import io.qameta.allure.Step;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static Helper.Elements.click;
import static Helper.Elements.waitEnableElement;

public class ListMaterials {
   private static final Logger LOG = Logger.getLogger(ListMaterials.class);

   @FindBy(xpath = "//*[@data-toggle='dropdown']")
   private WebElement create;

   @FindBy(xpath = "//*[@aria-labelledby='dropdownMenuButton']")
   private WebElement menu;

   @FindBy(xpath = "//a[@href='/admin/materials/news/create']")
   private WebElement buttonMenu;

   public ListMaterials() {
      PageFactory.initElements(Driver.getWebDriver(), this);
      waitEnableElement(create);
   }

   @Step(value = "Открываем страницу создания новой Новости")
   public MainTab createNews() {
      Driver.getWebDriver().navigate().to("http://" + Props.getProperty("host") + "/admin/materials/news/create");
      return new MainTab();
   }

   @Step(value = "Удаляем новость")
   public ListMaterials deleteNews(String nameNews) {
      LOG.info("Удаляем новость с именем " + nameNews);
      Driver.getWebDriver().navigate().to("http://" + Props.getProperty("host") + "/admin/materials");
      String linkForDelete = waitEnableElement(By.xpath("//a[contains(text(),'" + nameNews + "')]")).getAttribute("href");
      Driver.getWebDriver().navigate().to(linkForDelete);
      new MainTab().clickDelete().confirmDelete();
      LOG.info("Удалили новость");
      return new ListMaterials();
   }

   @Step(value = "Удаляем новость")
   public ListMaterials deleteNews(News nameNews) {
      return deleteNews(nameNews.getHeadline());
   }

   @Step(value = "Переходим на вкладку Корзина")
   public Basket goToBasket() {
      click(By.xpath("//a[@href='/admin/basket']"));
      return new Basket();
   }

   @Step(value = "Проверяем, что статус у новости Скрыто")
   public ListMaterials checkStatusNewsHidden(News news) {
      WebElement statusHidden = waitEnableElement(By.xpath("//a[contains(text(),'" + news.getHeadline() + "')]//ancestor-or-self::tr/td/i[@class='fa fa-eye-slash']"));
      waitEnableElement(statusHidden, "У новости с заголовком: '" + news.getHeadline() + "' не установлен статус Скрыто");
      return this;
   }

   @Step(value = "Ждем пока статус у новости станет Скрыто")
   public ListMaterials waitUntilNewsHidden(News news) {
      String error = "У новости с заголовком: '" + news.getHeadline() + "' не установлен статус Скрыто после истечения времени установленного в Публиковать до";
      waitEnableElement(By.xpath("//a[contains(text(),'" + news.getHeadline() + "')]//ancestor-or-self::tr/td/i[@class='fa fa-eye-slash']"), error, 135);
      return this;
   }

}
