package Pages.CreateNewNews;

import DriverBuilder.Driver;
import Exceptions.AutotestError;
import Objects.News;
import Pages.Content.ListMaterials;
import Pages.NewsPage;
import io.qameta.allure.Step;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static Helper.Elements.*;
import static Helper.Helper.*;

public class MainTab extends Menu {
    private static final Logger LOG = Logger.getLogger(MainTab.class);

    @FindBy(xpath = "(//button[@title='Сохраняет изменения и возвращает к списку страниц'])[1]")
    private WebElement saveClose;

    @FindBy(xpath = "(//*[@id='wrapper']//a[@target='_blank'])[1]")
    private WebElement onSite;

    @FindBy(xpath = "//input[@placeholder='Заголовок материала']")
    private WebElement headline;

    @FindBy(xpath = "//*[@name='menus']")
    private WebElement menuItems;

    @FindBy(xpath = "//*[@class='multiselect__tags']//input[(@placeholder='Начните вводить название рубрики')]")
    private WebElement rubricItems;

    @FindBy(xpath = "//*[@id='mceu_24']")
    private WebElement textArea;

    @FindBy(xpath = "(//label[text()='Автор']/following::div[@class='multiselect__tags'])[1]")
    private WebElement author;

    @FindBy(xpath = "(//label[text()='Источник']/following::div[@class='multiselect__tags'])[1]")
    private WebElement source;

    @FindBy(xpath = "(//label[text()='Теги']/following::div[@class='multiselect__tags'])[1]")
    private WebElement tags;

    @FindBy(xpath = "(//label[text()='Темы']/following::div[@class='multiselect__tags'])[1]")
    private WebElement topics;

    @FindBy(xpath = "(//label[text()='Похожие новости']/following::div[@class='multiselect__tags'])[1]")
    private WebElement similarNews;

    @FindBy(xpath = "(//label[text()='Персоны и органы власти, связанные со страницей']/following::div[@class='multiselect__tags'])[1]")
    private WebElement authorities;

    @FindBy(xpath = "(//label[text()='Фотоальбом']/following::div[@class='multiselect__tags'])[1]")
    private WebElement photoAlbum;

    @FindBy(xpath = "//*[text()='Материал успешно сохранен']")
    private WebElement successfullySaved;

    @FindBy(xpath = "(//div[@class='multiselect'])[1]")
    private WebElement status;

    @FindBy(xpath = "(//input[@placeholder='Заголовок материала']//following::small[text()='Поле обязательно для заполнения'])[1]")
    private WebElement requiredHeader;

    @FindBy(xpath = "(//label[text()='Анонс']/following::span[contains(text(),'Показать анонс')])[1]")
    private WebElement showPreview;

    @FindBy(xpath = "(//label[text()='Анонс']/following::span[contains(text(),'Скрыть анонс')])[1]")
    private WebElement hiddenPreview;

    @FindBy(xpath = "//*[@class='multiselect__tag-icon']")
    private List<WebElement> iconDelete;

    @FindBy(xpath = "(//label[text()='Публиковать до']/following::input)[1]")
    private WebElement postTo;

    public MainTab() {
        PageFactory.initElements(Driver.getWebDriver(), this);
        JavascriptExecutor jse = (JavascriptExecutor) Driver.getWebDriver();
        jse.executeScript("window.scrollTo(0,0)");
        waitEnableElement(textArea);
    }

    @Step(value = "Создаем новую новость, заполняем поля")
    public MainTab createNewNews(News news) {
        sentHeadline(news.getHeadline());
        sentMenuItems(news.getMenuItems());
        sentRubricItems(news.getRubricItems());
        sentText(news.getTextArea());
        sentAuthor(news.getAuthor());
        sentSource(news.getSource());
        sentTags(news.getTags());
        sentTopics(news.getTopics());
        sentSimilarNews(news.getSimilarNews());
        sentAuthorities(news.getAuthorities());
        sentPhotoAlbum(news.getPhotoAlbum());
        setStatusNews(news.getStatusNews());
        return this;
    }

    @Step(value = "Изменяем ранее созданную новость")
    public MainTab changeOldNews(News news) {
        for (WebElement icon : iconDelete) {
            click(icon);
        }
        sentHeadline(news.getHeadline());
        sentMenuItems(news.getMenuItems());
        sentRubricItems(news.getRubricItems());
        sentText(news.getTextArea());
        sentAuthor(news.getAuthor());
        sentSource(news.getSource());
        sentTags(news.getTags());
        sentTopics(news.getTopics());
        sentSimilarNews(news.getSimilarNews());
        sentAuthorities(news.getAuthorities());
        sentPhotoAlbum(news.getPhotoAlbum());
        setStatusNews(news.getStatusNews());
        return this;
    }

    @Step(value = "Нажимаем на кнопку Удалить")
    public MainTab clickDelete() {
        click(buttonDelete);
        return this;
    }

    @Step(value = "Нажимаем на кнопку Удалить еще раз")
    public MainTab confirmDelete() {
        LOG.info("Нажимаем на кнопку Удалить еще раз");
        click(confermDelete);
        return this;
    }

    @Step
    public NewsPage showNewsOnSite() {
        click(onSite, "Ошибка при создании Новой новости");
        return new NewsPage();
    }

    @Step(value = "Заполняем поле Текст")
    public MainTab sentText(String text) {
        if (null == text)
            return this;
        Driver.getWebDriver().switchTo().defaultContent().switchTo().frame(0);
        sendText(By.xpath("//*[@id='tinymce']"), text);
        Driver.getWebDriver().switchTo().defaultContent();
        return this;
    }

    @Step(value = "Заполняем поле Заголовок")
    public MainTab sentHeadline(String headlineTxt) {
        sendText(headline, headlineTxt);
        return this;
    }

    @Step(value = "Заполняем поле Фотоальбом")
    public MainTab sentPhotoAlbum(Object photoAlbumTxt) {
        if (null == photoAlbumTxt) {
            return this;
        }
        click(photoAlbum);
        if (photoAlbumTxt instanceof String & !"random".equals(photoAlbumTxt)) {
            click(By.xpath("//*[text()='" + photoAlbumTxt + "']"));
        } else {
            String countLocator = "//label[text()='Фотоальбом']/following-sibling::*//ul[@class='multiselect__content']/li/span[attribute::*[contains(local-name(),'data-select')]]/span";
            waitCountElementsToBeMoreT(By.xpath(countLocator), 2, "Кол-во пунктов меню в поле Фотоальбом меньше 2");
            int size = Driver.getWebDriver().findElements(By.xpath(countLocator)).size();
            String locator = "(//label[text()='Фотоальбом']/following::ul/li[" + (int) (Math.random() * size + 1) + "]/span/span)[1]";
            setStorage("Фотоальбом", waitEnableElement(By.xpath(locator)).getText());
            click(By.xpath(locator));
        }
/*      if (photoAlbumTxt instanceof Integer) {
         String locator = "(//label[text()='Фотоальбом']/following::ul/li[" + photoAlbumTxt + "]/span/span)[1]";
         setStorage("Фотоальбом", waitEnableElement(By.xpath(locator)).getText());
         click(By.xpath(locator));
      }*/
        return this;
    }

    @Step(value = "Заполняем поле Источник")
    public MainTab sentSource(Object sourceTxt) {
        if (null == sourceTxt) {
            return this;
        }
        click(source);
        if (sourceTxt instanceof String & !"random".equals(sourceTxt)) {
            click(By.xpath("//*[text()='" + sourceTxt + "']"));
        } else {
            String countLocator = "//label[text()='Источник']/following-sibling::*//ul[@class='multiselect__content']/li/span[attribute::*[contains(local-name(),'data-select')]]/span";
            waitCountElementsToBeMoreT(By.xpath(countLocator), 2, "Кол-во пунктов меню в поле Источник меньше 2");
            int size = Driver.getWebDriver().findElements(By.xpath(countLocator)).size();
            String locator = "(//label[text()='Источник']/following::ul/li[" + (int) (Math.random() * size + 1) + "]/span/span)[1]";
            setStorage("Источник", waitEnableElement(By.xpath(locator)).getText());
            click(By.xpath(locator));
        }
        return this;
    }

    @Step(value = "Заполняем поле Пункты меню")
    public MainTab sentMenuItems(Object menuItemsTxt) {
        if (null == menuItemsTxt) {
            return this;
        }
        click(menuItems);
        if (menuItemsTxt instanceof String & !"random".equals(menuItemsTxt)) {
            click(By.xpath("//*[text()='" + menuItemsTxt + "']"));
        } else {
            String countLocator = "//label[text()='Пункты меню']/following::ul/li/span/*[@data-id]";
            waitCountElementsToBeMoreT(By.xpath(countLocator), 2, "Кол-во пунктов меню в поле Пункты меню меньше 2");
            int size = Driver.getWebDriver().findElements(By.xpath(countLocator)).size();
            String locator = "(//label[text()='Пункты меню']/following::ul/li[" + (int) (Math.random() * size + 1) + "]/span/span)[1]";
            setStorage("Пункты меню", waitEnableElement(By.xpath(locator)).getText());
            click(By.xpath(locator));
        }
        return this;
    }

    @Step(value = "Заполняем поле Рубрики")
    public MainTab sentRubricItems(Object rubricItemsTxt) {
        if (null == rubricItemsTxt)
            return this;
        click(rubricItems);
        if (rubricItemsTxt instanceof String & !"random".equals(rubricItemsTxt)) {
            click(By.xpath("//*[text()='" + rubricItemsTxt + "']"));
        } else {
            String countLocator = "//label[text()='Рубрики']/following-sibling::*//ul[@class='multiselect__content']/li/span[attribute::*[contains(local-name(),'data-select')]]/span";
            waitCountElementsToBeMoreT(By.xpath(countLocator), 2, "Кол-во пунктов меню в поле Рубрики меньше 2");
            int size = Driver.getWebDriver().findElements(By.xpath(countLocator)).size();
            String locator = "(//label[text()='Рубрики']/following::ul/li[" + (int) (Math.random() * size + 1) + "]/span/span)[1]";
            setStorage("Рубрики", waitEnableElement(By.xpath(locator)).getText());
            click(By.xpath(locator));
        }
        return this;
    }

    @Step(value = "Заполняем поле Теги")
    public MainTab sentTags(Object tagsTxt) {
        if (null == tagsTxt) {
            return this;
        }
        click(tags);
        if (tagsTxt instanceof String & !"random".equals(tagsTxt)) {
            click(By.xpath("//*[text()='" + tagsTxt + "']"));
        } else {
            String countLocator = "//label[text()='Теги']/following-sibling::*//ul[@class='multiselect__content']/li/span[attribute::*[contains(local-name(),'data-select')]]/span";
            waitCountElementsToBeMoreT(By.xpath(countLocator), 2, "Кол-во пунктов меню в поле Теги меньше 2");
            int size = Driver.getWebDriver().findElements(By.xpath(countLocator)).size();
            String locator = "(//label[text()='Теги']/following::ul/li[" + (int) (Math.random() * size + 1) + "]/span/span)[1]";
            setStorage("Теги", waitEnableElement(By.xpath(locator)).getText());
            click(By.xpath(locator));
        }
        return this;
    }

    @Step(value = "Заполняем поле Темы")
    public MainTab sentTopics(Object topicsTxt) {
        if (null == topicsTxt) {
            return this;
        }
        click(topics);
        if (topicsTxt instanceof String & !"random".equals(topicsTxt)) {
            click(By.xpath("//*[text()='" + topicsTxt + "']"));
        } else {
            String countLocator = "//label[text()='Темы']/following-sibling::*//ul[@class='multiselect__content']/li/span[attribute::*[contains(local-name(),'data-select')]]/span";
            waitCountElementsToBeMoreT(By.xpath(countLocator), 2, "Кол-во пунктов меню в поле Темы меньше 2");
            int size = Driver.getWebDriver().findElements(By.xpath(countLocator)).size();
            String locator = "(//label[text()='Темы']/following::ul/li[" + (int) (Math.random() * size + 1) + "]/span/span)[1]";
            setStorage("Темы", waitEnableElement(By.xpath(locator)).getText());
            click(By.xpath(locator));
        }
        return this;
    }

    @Step(value = "Заполняем поле Похожие новости")
    public MainTab sentSimilarNews(Object similarNewsTxt) {
        if (null == similarNewsTxt) {
            return this;
        }
        click(similarNews);
        if (similarNewsTxt instanceof String & !"random".equals(similarNewsTxt)) {
            click(By.xpath("//*[text()='" + similarNewsTxt + "']"));
        } else {
            String countLocator = "//label[text()='Похожие новости']/following-sibling::*//ul[@class='multiselect__content']/li/span[attribute::*[contains(local-name(),'data-select')]]/span";
            waitCountElementsToBeMoreT(By.xpath(countLocator), 2, "Кол-во пунктов меню в поле Темы меньше 2");
            int size = Driver.getWebDriver().findElements(By.xpath(countLocator)).size();
            String locator = "(//label[text()='Похожие новости']/following::ul/li[" + (int) (Math.random() * size + 1) + "]/span/span)[1]";
            setStorage("Похожие новости", waitEnableElement(By.xpath(locator)).getText());
            click(By.xpath(locator));
        }
        return this;
    }

    @Step(value = "Заполняем поле Автор")
    public MainTab sentAuthor(Object authorTxt) {
        if (null == authorTxt) {
            return this;
        }
        click(author);
        if (authorTxt instanceof String & !"random".equals(authorTxt)) {
            click(By.xpath("//*[text()='" + authorTxt + "']"));
        } else {
            String countLocator = "//label[text()='Автор']/following-sibling::*//ul[@class='multiselect__content']/li/span[attribute::*[contains(local-name(),'data-select')]]/span";
            waitCountElementsToBeMoreT(By.xpath(countLocator), 2, "Кол-во пунктов меню в поле Автор меньше 2");
            int size = Driver.getWebDriver().findElements(By.xpath(countLocator)).size();
            String locator = "(//label[text()='Автор']/following::ul/li[" + (int) (Math.random() * size + 1) + "]/span/span)[1]";
            setStorage("Автор", waitEnableElement(By.xpath(locator)).getText());
            click(By.xpath(locator));
        }
        return this;
    }

    @Step(value = "Заполняем поле Персоны и органы власти")
    public MainTab sentAuthorities(Object authoritiesTxt) {
        if (null == authoritiesTxt) {
            return this;
        }
        click(authorities);
        if (authoritiesTxt instanceof String & !"random".equals(authoritiesTxt)) {
            click(By.xpath("//*[text()='" + authoritiesTxt + "']"));
        } else {
            String countLocator = "//label[text()='Персоны и органы власти, связанные со страницей']/following-sibling::*//ul[@class='multiselect__content']/li/span[attribute::*[contains(local-name(),'data-select')]]//span[1]";
            waitCountElementsToBeMoreT(By.xpath(countLocator), 2, "Кол-во пунктов меню в поле Персоны и органы власти, связанные со страницей меньше 2");
            int size = Driver.getWebDriver().findElements(By.xpath(countLocator)).size();
            String locator = "(//label[text()='Персоны и органы власти, связанные со страницей']/following::ul/li[" + (int) (Math.random() * size + 1) + "]/span[1]//span)[1]";
            setStorage("Персоны и органы власти", waitEnableElement(By.xpath(locator)).getText());
            click(By.xpath(locator));
        }
        return this;
    }

    @Step(value = "Переходим на вкладку Список материалов")
    public ListMaterials goToListMaterials() {
        click(By.xpath("//a[@href='/admin/materials']"));
        return new ListMaterials();
    }

    @Step(value = "Устанавливаем статус новости")
    public MainTab setStatusNews(Object statusText) {
        if (null == statusText)
            return this;
        click(status);
        click(By.xpath("//*[text()='" + statusText + "']"));
        return this;
    }

    @Step(value = "Проверяем что сообщения об ошибках появились")
    public MainTab checkErrorHeadlineField() {
        waitEnableElement(errorMessage, "Сообщение 'Данные введены неверно' не появилось");
        waitEnableElement(requiredHeader, "Ошибка для поля 'Заголовок' не возникла, новость без заполнения поля 'Заголовок' создалась");
        return this;
    }

    @Step(value = "Проверяем что сообщения об ошибках появились")
    public MainTab checkErrorTitleeField() {
        waitEnableElement(errorMessage, "При создании новости с заголовком более 200 символов, сообщение 'Данные введены неверно' не появилось");
        waitEnableElement(requiredHeader, "Ошибка для поля 'Заголовок' не возникла, Новость с заголовком более 200 символов можно создать");
        return this;
    }

    @Step(value = "Проверяем значение поля Заголовок")
    public MainTab checkTitle(News news) {
        String currentTitle = getNameValue(By.xpath("//input[@placeholder='Заголовок материала']"));
        if (!news.getHeadline().equals(currentTitle)) {
            new AutotestError("Заголовок на вкладке Основное изменился поле редактирования на вкладке SEO");
        }
        return this;
    }

    @Step(value = "Поле Анонс скрыто")
    public MainTab checkFieldPreviewHidden() {
        String locator = "(//label[text()='Анонс']/following::span[contains(text(),'Скрыть анонс')])[1]";
        waitCountElements(By.xpath(locator), 0, "Поле Анонс развернуто", 5);
        return this;
    }

    @Step(value = "Поле Анонс отображается")
    public MainTab checkFieldPreviewShow() {
        String locator = "(//label[text()='Анонс']/following::span[contains(text(),'Показать анонс')])[1]";
        waitCountElements(By.xpath(locator), 0, "Поле Анонс скрыто", 5);
        return this;
    }

    @Step(value = "Нажимаем кнопку показать анонс")
    public MainTab clickShowPreview() {
        click(showPreview);
        return this;
    }

    @Step(value = "Заполняем поле Анонс")
    public MainTab sentPreview(String text) {
        Driver.getWebDriver().switchTo().defaultContent().switchTo().frame(0);
        sendText(By.xpath("//*[@id='tinymce']"), text);
        Driver.getWebDriver().switchTo().defaultContent();
        return this;
    }

    @Step(value = "Проверяем значение поля Дата публикации")
    public MainTab checkFieldDate() {
        DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
        Date date = new Date();
        String[] currentDate = getNameValue(By.xpath("(//*[@class='form-group']//input[(@placeholder='С момента создания')])[2]")).split(" ");
        if (!currentDate[0].equals(dateFormat.format(date))) {
            new AutotestError("Значение поля Дата публикации не совпадает с текущем числом");
        }
        return this;
    }

    @Step(value = "Проверяем значение поля Пункты меню")
    public MainTab checkFieldItemsMenu(String result) {
        String curentText = waitEnableElement(By.xpath("(//*[@name='menus']/ancestor-or-self::*[@class='multiselect__tags']//span/span)[last()]"),
                "Значение поля 'Пункты меню' пустое.", 30).getText();
        if (!curentText.equals(result.trim())) {
            new AutotestError("Значение поля Пункты меню должно быть '" + result + "', но отображается '" + curentText + "'");
        }
        return this;
    }

    @Step(value = "Заполняем поле Публиковать до")
    public MainTab setPostTo() {
        int addMinuteTime = 2;
        DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        Date date = new Date();
        StringSelection stringSelection = new StringSelection(dateFormat.format(DateUtils.addMinutes(date, addMinuteTime)));
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, null);
        click(postTo);
        if (getStorage("os").equals("mac")) {
            postTo.sendKeys(Keys.COMMAND + "V");
        } else {
            postTo.sendKeys(Keys.CONTROL + "V");
        }
      /*Actions copyPast = new Actions(Driver.getWebDriver());
      Action past = (getStorage("os").equals("mac")) ?
            copyPast.keyDown(postTo, Keys.COMMAND).sendKeys(postTo, "V").keyUp(Keys.COMMAND).build() :
            copyPast.sendKeys(postTo, Keys.CONTROL).sendKeys(postTo, "V").build();
      past.perform();*/
        return this;
    }
}
