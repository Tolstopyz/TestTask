package Pages.Authorization;

import DriverBuilder.Driver;
import Pages.Content.ListMaterials;
import io.qameta.allure.Step;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static Helper.Elements.*;

public class AuthorizationPage {

   @FindBy(xpath = "(//*[@class='form-group']/input)[1]")
   private WebElement login;

   @FindBy(xpath = "//*[@type='password']")
   private WebElement password;

   @FindBy(xpath = "//*[@class='form-group']/button")
   private WebElement enter;

   public AuthorizationPage() {
      PageFactory.initElements(Driver.getWebDriver(), this);
      waitEnableElement(enter);
   }

   @Step(value = "Авторизуемся в системе")
   public ListMaterials login() {
      sendText(login, "test");
      sendText(password, "TlDgSNrrtHfgvjswzO4fQB0B614LnTmR");
      click(enter);
      return new ListMaterials();
   }

}
