package DriverBuilder;

public enum BrowserType {
    Chrome,
    FireFox
}
