package DriverBuilder;

import Helper.Props;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;

public class FirefoxDriverBuildr implements IWebDriverBuilder {

   private static WebDriver driver;
   private String pathToForeFox = this.getClass().getResource("/webdrivers/geckodriver.exe").getPath();

   public WebDriver GetDriver() {
      System.setProperty("webdriver.gecko.driver", pathToForeFox);
      driver = new FirefoxDriver(getFirefoxOptions()); //Нужно еще new TimeSpan(0, 5, 0)
      driver.manage().window().maximize();
      return driver;
   }

   private static FirefoxOptions getFirefoxOptions() {
      FirefoxOptions options = new FirefoxOptions();
      options.setBinary("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe"); //Location where Firefox is installed
      FirefoxProfile profile = new FirefoxProfile();
      profile.setPreference("browser.download.folderList", 2);
      profile.setPreference("browser.download.dir", Props.getProperty("pathToTestdataFolder"));
      profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
      profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
            "application/msword, application/binary, application/ris, text/csv, image/png, application/pdf, text/html, text/plain, application/zip,  application/x-zip, application/x-zip-compressed, application/download, application/octet-stream");
      DesiredCapabilities capabilities = DesiredCapabilities.firefox();
      capabilities.setCapability(FirefoxDriver.PROFILE, profile);
      capabilities.setCapability("marionette", true);
      capabilities.setCapability(FirefoxDriver.PROFILE, profile);
      return options;
   }

   /* private static DesiredCapabilities GetFirefoxCapabilities() {
        DesiredCapabilities capability = new DesiredCapabilities();
        FirefoxProfile profile = new FirefoxProfile();
        profile.setPreference("browser.download.folderList", 2);
        profile.setPreference("browser.download.dir", Props.getProperty("pathToTestdataFolder"));
        profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
        profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/msword, application/binary, application/ris, text/csv, image/png, application/pdf, text/html, text/plain, application/zip,  application/x-zip, application/x-zip-compressed, application/download, application/octet-stream");
        capability.setCapability(FirefoxDriver.PROFILE, profile);
        capability.setCapability("marionette", true);
        capability.setCapability(FirefoxDriver.PROFILE, profile);
        return capability;
    }*/
}
