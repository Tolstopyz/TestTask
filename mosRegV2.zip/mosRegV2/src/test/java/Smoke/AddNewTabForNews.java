package Smoke;

import Objects.News;
import Objects.Tabs;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.deleteNews;

public class AddNewTabForNews extends BaseTests {
   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   private Tabs newTabs = new Tabs(
         "Вкладка для теста",
         "Текст для новой вкладки");

   @Test(description = "Добавление новой вкладки при создании новой новости")
   public void addNewTab() {
      LOG.info("***** Запускаем тест Добавление новой вкладки при создании новой новости *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            goToTabs().
            addNewTab(newTabs).
            clickSave().
            clickOnSite().
            checkBodyTitle(testNews).
            checkTab(newTabs).
            checkTextTab(newTabs);
   }

   @AfterMethod
   public void after() {
      deleteNews(testNews);
   }
}
