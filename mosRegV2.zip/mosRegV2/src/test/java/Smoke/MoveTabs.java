package Smoke;

import Objects.News;
import Objects.Tabs;
import Pages.Authorization.AuthorizationPage;
import Pages.CreateNewNews.TabsTab;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

import static Helper.Helper.closeTabAndSwitchMainWindow;
import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.deleteNews;

public class MoveTabs extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   private Tabs firstTabs = new Tabs(
         "Первая вкладка",
         "Текст для первой вкладки");

   private Tabs secondTabs = new Tabs(
         "Вторая вкладка",
         "Текст для второй вкладки");

   private List<Tabs> allTabs = Arrays.asList(firstTabs, secondTabs);

   @Test(description = "Пользователь может изменить порядок вкладок")
   public void addNewTab() {
      LOG.info("***** Запускаем тест Пользователь может изменить порядок вкладок *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            goToTabs().
            addSeveralTabs(allTabs).
            clickSave().
            clickOnSite().
            checkBodyTitle(testNews).
            checkTabsAndText(allTabs).
            chechOrderTabs(allTabs);
      closeTabAndSwitchMainWindow();
      new TabsTab().
            upTabOnTop(secondTabs).
            clickSave().
            clickOnSite().
            checkBodyTitle(testNews).
            checkTabsAndText(allTabs).
            chechOrderTabs(Arrays.asList(secondTabs, firstTabs));
   }

   @AfterMethod
   public void after() {
      deleteNews(testNews);
   }
}
