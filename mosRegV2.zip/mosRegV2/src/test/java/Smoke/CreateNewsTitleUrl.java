package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.afterAddNewsTitleUrl;

public class CreateNewsTitleUrl extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   private String url = "testurlfornews";

   @Test(description = "Создание новости с заполненным заголовком и URL")
   public void addNewsTitleUrl() {
      LOG.info("***** Запускаем тест Создание новости с заполненным заголовком и URL *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            goToPageSetting().
            sentUrl(url).
            clickSave().
            clickOnSite().
            checkCorrectTitleAndUrl(testNews, url);
   }

   @AfterMethod
   public void after() {
      afterAddNewsTitleUrl(testNews);
   }
}
