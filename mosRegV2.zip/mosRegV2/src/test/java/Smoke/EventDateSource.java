package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.deleteNewsWithoutClose;

public class EventDateSource extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   private String source = "Управление пресс-службы губернатора и правительства Московской области";
   private String result = "Главная / Губернатор / Пресс-служба / Анонсы";

   @Test(description = "При заполнении поля Дата события и Источник Управление пресс-службы губернатора и правительства Московской области")
   public void addTypeEventDate() {
      LOG.info("***** Запускаем тест При заполнении поля Дата события и Источник Управление пресс-службы губернатора и правительства Московской области *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            sentSource(source).
            goToEvent().
            sentDateEvent().
            clickSave().
            goToMain().
            checkFieldItemsMenu(result);
   }

   @AfterTest
   public void after() {
      deleteNewsWithoutClose(testNews);
   }
}
