package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckMinLengthPhone extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет поле Номер телефона менее 10 символов")
    public void addFeedbackWithoutEmail() {
        LOG.info("***** Пользоватль заполняет поле Номер телефона менее 10 символов *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentPhoneNumber("+79201111")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonSent()
                .checkErrorMinLengthPhone();
    }
}
