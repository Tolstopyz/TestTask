package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckFormatEmailCoAuthor extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет поле Email соавтор не по формату")
    public void addFeedbackWithoutEmail() {
        LOG.info("***** Пользоватль заполняет поле Email соавтор не по формату *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonAddCoAuthor()
                .sentCoAuthorName("Артем")
                .sentCoAuthorSurname("Иванов")
                .sentCoAuthorEmail("mail@mail")
                .clickButtonSent()
                .checkErrorFormatCoAuthorEmail();
    }
}
