package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckLengthSurnameCoAuthor extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет поле соавтор Фамилия менее 3х символов")
    public void addFeedbackWithoutEmail() {
        LOG.info("***** Пользоватль заполняет поле соавтор Фамилия менее 3х символов *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonAddCoAuthor()
                .sentCoAuthorName("Артем")
                .sentCoAuthorSurname("Ив")
                .clickButtonSent()
                .checkErrorLengthCoAuthorSurname();
    }
}
