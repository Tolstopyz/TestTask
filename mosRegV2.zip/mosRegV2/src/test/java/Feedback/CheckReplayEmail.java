package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckReplayEmail extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет все обязательные поля кроме повтора Email")
    public void addFeedbackWithoutReplayEmail() {
        LOG.info("***** Пользоватль заполняет все поля кроме повтора Email *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonSent()
                .checkErrorReplayEmail();
    }
}
