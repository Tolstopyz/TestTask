package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckCyrillicEmail extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет поле Повторите адрес эл. почты кирилицей")
    public void addFeedbackWithoutEmail() {
        LOG.info("***** Пользоватль заполняет поле Повторите адрес эл. почты кирилицей *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("антон")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonSent()
                .checkErrorСyrillicEmail();
    }
}
