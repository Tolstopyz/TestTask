package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckLengthSurname extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет поле Фамилия менее 3х символов")
    public void addFeedbackWithoutEmail() {
        LOG.info("***** Пользоватль заполняет поле Фамилия менее 3х символов *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Пе")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonSent()
                .checkErrorLengthSurname();
    }
}
