package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckCoAuthorName extends BaseFeedbackTests {
    @Test(description = "Пользователь добавляет соавторов обращения но не заполняет поле Имя")
    public void addFeedbackWithoutName() {
        LOG.info("***** Пользователь добавляет соавторов обращения но не заполняет поле Имя *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonAddCoAuthor()
                .sentCoAuthorSurname("Иванов")
                .clickButtonSent()
                .checkErrorCoAuthorName();
    }
}
