package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckMaxLengthPhone extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет поле Номер телефона более 64 символов")
    public void addFeedbackWithoutEmail() {
        LOG.info("***** Пользоватль заполняет поле Номер телефона более 64 символов *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentPhoneNumber("+79541222545523654412554123665444127777888965541225412236544125125")
                .sentAppealText("Текст обращения от Антона")
                .checkErrorMinLengthPhoneNoExist();
    }
}
