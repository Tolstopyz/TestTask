package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckFormatEmail extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет поле Email не по формату")
    public void addFeedbackWithoutEmail() {
        LOG.info("Пользоватль заполняет поле Email не по формату");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonSent()
                .checkErrorFormatEmail();
    }
}
