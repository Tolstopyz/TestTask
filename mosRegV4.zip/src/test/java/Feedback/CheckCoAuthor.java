package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckCoAuthor extends BaseFeedbackTests {
    @Test(description = "Пользователь добавляет соавторов обращения но не заполняет поля")
    public void addFeedbackWithoutName() {
        LOG.info("***** Пользователь добавляет соавторов обращения но не заполняет поля *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonAddCoAuthor()
                .clickButtonSent()
                .checkErrorCoAuthorName()
                .checkErrorCoAuthorSurname();
    }
}
