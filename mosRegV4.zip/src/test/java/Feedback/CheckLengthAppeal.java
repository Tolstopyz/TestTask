package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckLengthAppeal extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет поле Текст обращения менее 10 символов")
    public void addFeedbackWithoutEmail() {
        LOG.info("***** Пользоватль заполняет поле Текст обращения менее 10 символов *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentAppealText("Текст")
                .clickButtonSent()
                .checkErrorLengtAppealText();
    }
}
