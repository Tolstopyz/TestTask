package Feedback;

import Pages.Feedback;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Smoke.AfterTests.afterOtherTests;

public class CheckCustomMessage extends BaseFeedbackTests {
    @Test(description = "Пользователь снимает галку Принимаю условия Пользовательского соглашения")
    public void addFeedbackWithoutAppealText() {
        LOG.info("***** Пользователь снимает галку Принимаю условия Пользовательского соглашения *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentMiddleName("Иванович")
                .clickCheckBoxCustomMessage()
                .checkErrorCustomMessage();
    }

    @AfterTest
    public void after() {
        afterOtherTests();
    }
}
