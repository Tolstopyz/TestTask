package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckLengthName extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет поле Имя менее 2х символов")
    public void addFeedbackWithoutEmail() {
        LOG.info("***** Пользоватль заполняет поле Имя менее 2х символов *****");
        new Feedback()
                .sentName("О")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonSent()
                .checkErrorLengthName();
    }
}
