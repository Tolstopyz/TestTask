package Feedback;

import Pages.Feedback;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Smoke.AfterTests.afterOtherTests;

public class CheckCheckBoxNoMiddleName extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет все поля и нажимает CheckBox Отчество отсутствует")
    public void addFeedbackWithoutAppealText() {
        LOG.info("***** Пользоватль заполняет все поля и нажимает CheckBox Отчество отсутствует *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .clickCheckBoxNoMiddleName()
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentPhoneNumber("+79211111111")
                .sentAppealText("Текст обращения от Антона")
                .sentCapchaText("Текст Капча")
                .clickButtonSent()
                .errorMessageСapchaError();
    }

    @AfterTest
    public void after() {
        afterOtherTests();
    }
}
