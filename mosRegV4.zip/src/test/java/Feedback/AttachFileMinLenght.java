package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class AttachFileMinLenght extends BaseFeedbackTests {
    @Test(description = "Пользоватль прикрепляет файл 0 кб")
    public void attachMinFile() {
        LOG.info("***** Пользоватль прикрепляет файл 0 кб *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .attachFile("meta_info.lck")
                .checkErrorMinLengthFile();
    }
}
