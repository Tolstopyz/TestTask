package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class AttachFileWithoutFormat extends BaseFeedbackTests {
    @Test(description = "Пользоватль прикрепляет файл без расширения")
    public void attachMinFile() {
        LOG.info("***** Пользоватль прикрепляет файл без расширения *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .attachFile("Basik")
                .checkErrorFileWithoutFormat();
    }
}
