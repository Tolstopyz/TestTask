package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckSameReplayEmail extends BaseFeedbackTests {
    @Test(description = "Пользователь заполняет все обязательные поля но повтор Email не совпадает")
    public void addFeedbackWithoutReplayEmail() {
        LOG.info("***** Пользователь заполняет все обязательные поля но повтор Email не совпадает *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("ton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonSent()
                .checkErrorReplayEmailValues();
    }
}
