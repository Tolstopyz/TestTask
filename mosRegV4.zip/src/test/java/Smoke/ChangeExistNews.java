package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import Pages.CreateNewNews.MainTab;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static Helper.Helper.closeTabAndSwitchMainWindow;
import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.deleteNews;

public class ChangeExistNews extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Текст для проверки добавления новых новостей",
         "Опубликовано");

   private News changetNews = new News(
         "Изменили Заголовок Автотестов",
         "Измененный текст для проверки редактирования новостей",
         "Опубликовано");

   @Test(description = "Изменения ранее созданной новости")
   public void changeExistNews() {
      LOG.info("***** Запускаем тест Изменения ранее созданной новости *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            clickSave().
            clickOnSite().
            checkCorrectNewNews(testNews);
      closeTabAndSwitchMainWindow();
      new MainTab().
            changeOldNews(changetNews).
            clickSave().
            clickOnSite().
            checkCorrectNewNews(changetNews);
   }

   @AfterMethod
   public void after() {
      deleteNews(changetNews);
   }

}
