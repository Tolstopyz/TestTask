package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.afterOtherTests;

public class CreateNewsEmptyUrl extends BaseTests {
   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   @Test(description = "Создание новости с незаполненным URL")
   public void addNewsTitleEmptyUrl() {
      LOG.info("***** Запускаем тест Создание новости с незаполненным URL *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            goToPageSetting().
            sentUrl(" ").
            clickSave().
            goToPageSetting().
            checkErrorUrlField();
   }

   @AfterMethod
   public void after() {
      afterOtherTests();
   }

}
