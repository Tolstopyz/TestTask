package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.afterOtherTests;

public class TabPreviewShow extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   private String previewText = "Тестовый текс для Анонса";

   @Test(description = "При создании новости если разернуть поле Анонс то оно остается развернутым")
   public void tabShowPreview() {
      LOG.info("***** Запускаем тест 'При создании новости если разернуть поле Анонс то оно остается развернутым' *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            clickShowPreview().
            sentPreview(previewText).
            goToSeo().
            goToMain().
            checkFieldPreviewShow();
   }

   @AfterTest
   public void after() {
      afterOtherTests();
   }
}
