package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.deleteNewsFromListMaterials;

public class NewsPublishTo extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   @Test(description = "После окончания Публиковать До, статус становится Скрытая")
   public void publishToDate() {
      LOG.info("***** Запускаем тест После окончания Публиковать До, статус становится Скрытая *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            setPostTo().
            clickSave().
            goToListMaterialsByUrl().
            waitUntilNewsHidden(testNews);
   }

   @AfterTest
   public void deleteCreatedNews() {
      deleteNewsFromListMaterials(testNews);
   }
}
