package Smoke;

import Objects.News;
import Objects.Tabs;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.deleteNews;

public class AddSeveralTabsForNews extends BaseTests {

    private News testNews = new News(
            getRandomHeadline(),
            "Опубликовано");

    private Tabs firstTabs = new Tabs(
            "Первая вкладка",
            "Текст для первой вкладки");

    private Tabs secondTabs = new Tabs(
            "Вторая вкладка",
            "Текст для второй вкладки");

    private Tabs thirdTabs = new Tabs(
            "Третья вкладка",
            "Текст для третьей вкладки");

    private List<Tabs> allTabs = Arrays.asList(firstTabs, secondTabs, thirdTabs);

    @Test(description = "Добавление нсколько вкладок при создании новой новости")
    public void addSeveralNewTab() {
        LOG.info("***** Запускаем тест Добавление нсколько вкладок при создании новой новости *****");
        new AuthorizationPage().
                login().
                createNews().
                createNewNews(testNews).
                goToTabs().
                addSeveralTabs(allTabs).
                clickSave().
                clickOnSite().
                checkBodyTitle(testNews).
                checkTabsAndText(allTabs);
    }

    @AfterMethod
    public void after() {
        deleteNews(testNews);
    }
}
