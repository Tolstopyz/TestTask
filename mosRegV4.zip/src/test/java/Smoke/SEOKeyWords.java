package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.deleteNewsWithoutClose;

public class SEOKeyWords extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(), "Текст для проверки добавления новых новостей",
         "Опубликовано");

   @Test(description = "Ключевые слова на вкладке SEO автоматически выставляются")
   public void SeoWords() {
      LOG.info("***** Запускаем тест Ключевые слова на вкладке SEO автоматически выставляются *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            clickSave().
            goToSeo().
            checkWordKeys(testNews);
   }

   @AfterTest
   public void after() {
      deleteNewsWithoutClose(testNews);
   }
}
