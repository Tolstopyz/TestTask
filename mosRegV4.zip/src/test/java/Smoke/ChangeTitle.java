package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.closePage;

public class ChangeTitle extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   private String title = "Change url";

   @Test(description = "Заголовок не изменится если поменять его на вкладке Настройка страницы")
   public void сhangeTitle() {
      LOG.info("***** Запускаем тест Заголовок не изменится если поменять его на вкладке Настройка страницы *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            goToPageSetting().
            checkUrl(testNews.getHeadline()).
            sentUrl(title).
            goToMain().
            checkTitle(testNews);
   }

   @AfterMethod
   public void after() {
      closePage();
   }

}
