package Exceptions;

public class UnknownDriverTypeException extends RuntimeException {

   public UnknownDriverTypeException(String msg) {
      super(msg);
   }

}
