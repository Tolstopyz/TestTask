package Exceptions;

public class ReadExcelFileException extends RuntimeException {
   public ReadExcelFileException(String msg) {
      super(msg);
   }
}
