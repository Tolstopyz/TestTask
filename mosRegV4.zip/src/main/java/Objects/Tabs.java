package Objects;

public class Tabs {

   private String nameTab;

   private String textTab;

   public Tabs(String nameTab, String textTab) {
      this.nameTab = nameTab;
      this.textTab = textTab;
   }

   public String getNameTab() {
      return nameTab;
   }

   public String getTextTab() {
      return textTab;
   }
}
