package DriverBuilder;

import Exceptions.UnknownDriverTypeException;
import Helper.Props;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.IOException;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.HashMap;
import java.util.Map;

import static Helper.Helper.setStorage;
import static java.nio.file.Files.setPosixFilePermissions;

public class ChromeDriverBuilder implements IWebDriverBuilder {

   private static WebDriver driver;
   private static Map<String, Object> prefs;

   static {
      prefs = new HashMap<>();
      prefs.put("download.default_directory", Props.getProperty("pathToTestdataFolder"));
      prefs.put("download.extensions_to_open", "exe:msi:pkg");
      prefs.put("unexpectedAlertBehaviour", "ignore");
      prefs.put("safebrowsing.enabled", true);
   }

   public WebDriver GetDriver() {
      System.setProperty("webdriver.chrome.driver", choosePathOs());
      driver = new ChromeDriver(GetChromeOptions());
      driver.manage().window().maximize();
      return driver;
   }

   private static ChromeOptions GetChromeOptions() {
      ChromeOptions options = new ChromeOptions();
      options.addArguments("start-maximized");
      options.addArguments("disable-cache");
      options.addArguments("disable-gpu-program-cache");
      options.addArguments("disable-application-cache");
      options.setExperimentalOption("prefs", prefs);
      return options;
   }

   private static String choosePathOs() {
      String osName = System.getProperty("os.name").toLowerCase();
      if (osName.indexOf("win") >= 0) {
         setStorage("os", "win");
         return "./src/main/resources/chromedriver.exe";
      } else if (osName.indexOf("mac") >= 0) {
         setStorage("os", "mac");
         return "./src/main/resources/chromedriver_mac";
      } else {
         setStorage("os", "unix");
         String pathToChrome = "./src/main/resources/chromedriver_linux";
         try {
            setPosixFilePermissions(Paths.get(pathToChrome), PosixFilePermissions.fromString("rwxr-xr-x"));
         } catch (IOException e) {
            throw new UnknownDriverTypeException("Set permission 755 for file " + pathToChrome);
         }
         return pathToChrome;
      }
   }
}
