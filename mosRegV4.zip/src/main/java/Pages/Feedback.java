package Pages;

import DriverBuilder.Driver;
import io.qameta.allure.Step;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.File;

import static Helper.Elements.*;

public class Feedback {

    private static final Logger LOG = Logger.getLogger(Feedback.class);

    @FindBy(xpath = "//*[@class='col-sm-8']//input[@id='field237.field255']")
    private WebElement surname;

    @FindBy(xpath = "//*[@class='col-sm-8']//input[@id='field237.field261']")
    private WebElement name;

    @FindBy(xpath = "//*[@class='col-sm-8']//input[@id='field237.field267']")
    private WebElement middleName;

    @FindBy(xpath = "//*[@class='col-sm-8']//input[@id='field237.field279']")
    private WebElement nameCompany;

    @FindBy(xpath = "//*[@class='col-sm-8']//input[@id='field237.field291']")
    private WebElement email;

    @FindBy(xpath = "//*[@class='col-sm-8']//input[@id='field237.field297']")
    private WebElement replayEmail;

    @FindBy(xpath = "//*[@class='col-sm-8']//input[@id='field237.field303']")
    private WebElement phoneNumber;

    @FindBy(xpath = "//*[@class='form-group']//button[contains(@class,'btn-transparent--black')]")
    private WebElement buttonAdd;

    @FindBy(xpath = "//textarea[@id='field237.field351']")
    private WebElement appealText;

    @FindBy(xpath = "//*[@class='form-control-wrapper2']/input[@type='button']")
    private WebElement buttonSent;

    @FindBy(xpath = "//label[@for='field237.field261' and contains(text(),'Поле обязательно для заполнения')]")
    private WebElement errorName;

    @FindBy(xpath = "//label[@for='field237.field255' and contains(text(),'Поле обязательно для заполнения')]")
    private WebElement errorSurname;

    @FindBy(xpath = "//label[@for='field237.field291' and contains(text(),'Поле обязательно для заполнения')]")
    private WebElement errorEmail;

    @FindBy(xpath = "//label[@for='field237.field297' and contains(text(),'Поле обязательно для заполнения')]")
    private WebElement errorReplayEmail;

    @FindBy(xpath = "//label[@for='field237.field351' and contains(text(),'Поле обязательно для заполнения')]")
    private WebElement errorAppealText;

    @FindBy(xpath = "//label[@for='field237.field297' and contains(text(),'Значения не совпадают')]")
    private WebElement errorReplayEmailValues;

    @FindBy(xpath = "//input[@type='file']")
    private WebElement attache;

    @FindBy(xpath = "//label[@for='field237.field261' and contains(text(),'Вы должны ввести не менее 2 символов')]")
    private WebElement errorLengthName;

    @FindBy(xpath = "//label[@for='field237.field255' and contains(text(),'Вы должны ввести не менее 3 символов')]")
    private WebElement errorLengthSurname;

    @FindBy(xpath = "//label[@for='field237.field351' and contains(text(),'Вы должны ввести не менее 10 символов')]")
    private WebElement errorLengthAppeal;

    @FindBy(xpath = "//label[@for='field237.field303' and contains(text(),'Вы должны ввести не менее 10 символов')]")
    private WebElement errorMinLengthPhone;

    @FindBy(xpath = "//label[@for='field237.field297' and contains(text(),'Вы должны указать действительный адрес электронной почты')]")
    private WebElement errorEmailСyrillic;

    @FindBy(xpath = "//label[@for='field237.field369' and contains(text(),'Загружен файл размером 0 Kб, пожалуйста, проверьте загружаемые файлы')]")
    private WebElement errorMinLengthFile;

    @FindBy(xpath = "//label[@for='field237.field369' and contains(text(),'Превышен максимальный размер файлов')]")
    private WebElement errorBigLengthFile;

    @FindBy(xpath = "//label[@for='field237.field369' and contains(text(),'Загружен файл без расширения, проверьте загружаемые файлы')]")
    private WebElement errorFileWithoutFormat;

    @FindBy(xpath = "//label[@for='field237.field291' and contains(text(),'Вы должны указать действительный адрес электронной почты')]")
    private WebElement errorLengthEmail;

    @FindBy(xpath = "//label[@for='field237.field369' and contains(text(),'Загружен файл недопустимого формата, проверьте загружаемые файлы')]")
    private WebElement errorFormatFile;

    @FindBy(xpath = "//*[@class='form-control-wrapper']//*[contains(text(),'Добавить')]")
    private WebElement coAuthor;

    @FindBy(xpath = "//label[@for='field237.field309.0.field321' and contains(text(),'Поле обязательно для заполнения')]")
    private WebElement coAuthorErrorName;

    @FindBy(xpath = "//label[@for='field237.field309.0.field315' and contains(text(),'Поле обязательно для заполнения')]")
    private WebElement coAuthorErrorSurname;

    @FindBy(xpath = "//input[@id='field237.field309.0.field321']")
    private WebElement coAuthorName;

    @FindBy(xpath = "//input[@id='field237.field309.0.field315']")
    private WebElement coAuthorSurname;

    @FindBy(xpath = "//input[@id='field237.field309.0.field327']")
    private WebElement coAuthorMiddleName;

    @FindBy(xpath = "//label[@for='field237.field309.0.field321' and contains(text(),'Вы должны ввести не менее 2 символов')]")
    private WebElement errorLengthSoAuthorName;

    @FindBy(xpath = "//label[@for='field237.field309.0.field315' and contains(text(),'Вы должны ввести не менее 3 символов')]")
    private WebElement errorLengthSoAuthorSurname;

    @FindBy(xpath = "//label[@for='field237.field381' and contains(text(),'Неправильный код проверки')]")
    private WebElement capchaError;

    @FindBy(xpath = "//input[@id='field237.field309.0.field333']")
    private WebElement coAuthorEmail;

    @FindBy(xpath = "//label[@for='field237.field387' and contains(text(),'Вы должны принять условия пользовательского соглашения')]")
    private WebElement errorCustomMessage;

    @FindBy(xpath = "//input[@id='field237.field309.1.field333']")
    private WebElement coAuthor2Email;

    @FindBy(xpath = "//input[@id='field237.field309.1.field321']")
    private WebElement coAuthor2Name;

    @FindBy(xpath = "//input[@id='field237.field381']")
    private WebElement capcha;

    @FindBy(xpath = "//input[@id='field237.field309.1.field315']")
    private WebElement coAuthor2Surname;

    @FindBy(xpath = "//input[@id='field237.field309.1.field327']")
    private WebElement coAuthor2MiddleName;

    @FindBy(xpath = "//label[@for='field237.field309.0.field333' and contains(text(),'Вы должны указать действительный адрес электронной почты')]")
    private WebElement errorLengthSoAuthorEmail;

    @FindBy(xpath = "//*[@class='form-input-file-wrap']/div")
    private WebElement buttonRemoveAttach;

    @FindBy(xpath = "//*[@class='col-sm-8']//*[contains(text(),'Выбрано файлов')]")
    private WebElement massageAttachFile;

    @FindBy(xpath = "//label[contains(text(),'Отчество отсутствует')]")
    private WebElement middleNameCheckBox;

    @FindBy(xpath = "//*[@class='mfp-content']//div[text()='Обращение отправлено']")
    private WebElement appealSent;

    @FindBy(xpath = "//*[@class='group__item']//*[@class='group__counter' and text()='2 соавтор']//..//*[@class='group__remove']")
    private WebElement delete2CoAuthor;

    @FindBy(xpath = "//*[@class='form-control-wrapper1']//*[@class='check']")
    private WebElement applayCustomMessage;

    public Feedback() {
        PageFactory.initElements(Driver.getWebDriver(), this);
        waitEnableElement(appealText);
    }

    @Step(value = "Заполняем поле Имя")
    public Feedback sentName(String text) {
        sendText(name, text);
        return this;
    }

    @Step(value = "Заполняем поле Фамилия")
    public Feedback sentSurname(String text) {
        sendText(surname, text);
        return this;
    }

    @Step(value = "Заполняем поле Отчество")
    public Feedback sentMiddleName(String text) {
        sendText(middleName, text);
        return this;
    }

    @Step(value = "Заполняем поле соавтор Имя")
    public Feedback sentCoAuthorName(String text) {
        sendText(coAuthorName, text);
        return this;
    }

    @Step(value = "Заполняем поле соавтор Фамилия")
    public Feedback sentCoAuthorSurname(String text) {
        sendText(coAuthorSurname, text);
        return this;
    }

    @Step(value = "Заполняем поле соавтор Отчество")
    public Feedback sentCoAuthorMiddleName(String text) {
        sendText(coAuthorMiddleName, text);
        return this;
    }

    @Step(value = "Заполняем поле соавтор Эл. почты")
    public Feedback sentCoAuthorEmail(String text) {
        sendText(coAuthorEmail, text);
        return this;
    }

    @Step(value = "Заполняем поле соавтор 2 Имя")
    public Feedback sentCoAuthor2Name(String text) {
        sendText(coAuthor2Name, text);
        return this;
    }

    @Step(value = "Заполняем поле соавтор 2 Фамилия")
    public Feedback sentCoAuthor2Surname(String text) {
        sendText(coAuthor2Surname, text);
        return this;
    }

    @Step(value = "Заполняем поле соавтор 2 Отчество")
    public Feedback sentCoAuthor2MiddleName(String text) {
        sendText(coAuthor2MiddleName, text);
        return this;
    }

    @Step(value = "Заполняем поле соавтор 2 Эл. почты")
    public Feedback sentCoAuthor2Email(String text) {
        sendText(coAuthor2Email, text);
        return this;
    }

    @Step(value = "Заполняем поле Адрес эл. почты")
    public Feedback sentEmail(String text) {
        sendText(email, text);
        return this;
    }

    @Step(value = "Заполняем поле Повторите адрес эл. почты")
    public Feedback sentReplayEmail(String text) {
        sendText(replayEmail, text);
        return this;
    }

    @Step(value = "Заполняем поле Номер телефона")
    public Feedback sentPhoneNumber(String text) {
        sendText(phoneNumber, text);
        return this;
    }

    @Step(value = "Заполняем поле Наименование организации")
    public Feedback sentNameCompany(String text) {
        sendText(nameCompany, text);
        return this;
    }

    @Step(value = "Нажимаем кнопку Добавить")
    public Feedback clickButtonAdd() {
        click(buttonAdd);
        return this;
    }

    @Step(value = "Нажимаем кнопку Удалить прикрепленный файл")
    public Feedback clickButtonRemoveAttach() {
        click(buttonRemoveAttach);
        String locator = "//*[@class='col-sm-8']//*[contains(text(),'Выбрано файлов')]";
        waitCountElements(By.xpath(locator), 0, "Прикрепленный файл не удален", 3);
        return this;
    }

    @Step(value = "Нажимаем кнопку Отправить")
    public Feedback clickButtonSent() {
        click(buttonSent);
        return this;
    }

    @Step(value = "Заполняем поле Текст обращения")
    public Feedback sentAppealText(String text) {
        sendText(appealText, text);
        return this;
    }

    @Step(value = "Заполняем поле Капча")
    public Feedback sentCapchaText(String text) {
        sendText(capcha, text);
        return this;
    }

    @Step(value = "Нажимает кнопку добавить соавторов")
    public Feedback clickButtonAddCoAuthor() {
        click(coAuthor);
        return this;
    }

    @Step(value = "Прикрепляет файл")
    public Feedback attachFile(String fileName) {
        String pathToFile = new File("src/main/resources/filesForAttach/" + fileName).getAbsolutePath();
        LOG.info("Прикрепляем файл по пути " + pathToFile);
        attache.sendKeys(pathToFile);
        waitEnableElement(massageAttachFile);
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при незаполненом поле Имя")
    public Feedback checkErrorName() {
        waitEnableElement(errorName, "Сообщение 'Поле обязательно для заполнения' для поля Имя не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при незаполненом поле Фамилия")
    public Feedback checkErrorSurname() {
        waitEnableElement(errorSurname, "Сообщение 'Поле обязательно для заполнения' для поля Фамилия не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при незаполненом поле Email")
    public Feedback checkErrorEmail() {
        waitEnableElement(errorEmail, "Сообщение 'Поле обязательно для заполнения' для поля Email не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при незаполненом поле повтор Email")
    public Feedback checkErrorReplayEmail() {
        waitEnableElement(errorReplayEmail, "Сообщение 'Поле обязательно для заполнения' для поля Повтор Email не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при снятие галки Принимаю условия Пользовательского соглашения")
    public Feedback checkErrorCustomMessage() {
        waitEnableElement(errorCustomMessage, "Сообщение 'Поле обязательно для заполнения' для поля Повтор Email не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при незаполненом поле Текст обращения")
    public Feedback checkErrorAppealText() {
        waitEnableElement(errorAppealText, "Сообщение 'Поле обязательно для заполнения' для поля Текст обращения не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при несовпадения значения в поле Повторите адрес эл. почты")
    public Feedback checkErrorReplayEmailValues() {
        waitEnableElement(errorReplayEmailValues, "Сообщение 'Значения не совпадают' для поля Повторите адрес эл. почты не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при вводе менее 3х символов в поле Фамилия")
    public Feedback checkErrorLengthName() {
        waitEnableElement(errorLengthName, "Сообщение 'Вы должны ввести не менее 3х символов' для поля Фамилия не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при вводе менее 2х символов в поле Имя")
    public Feedback checkErrorLengthSurname() {
        waitEnableElement(errorLengthSurname, "Сообщение 'Вы должны ввести не менее 2х символов' для поля Имя не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при вводе менее 10х символов в поле Текст обращения")
    public Feedback checkErrorLengtAppealText() {
        waitEnableElement(errorLengthAppeal, "Сообщение 'Вы должны ввести не менее 10 символов' для поля Текст обращения не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при вводе кирилицы в поле Повторите адрес эл. почты")
    public Feedback checkErrorСyrillicEmail() {
        waitEnableElement(errorEmailСyrillic, "Сообщение 'Вы должны указать действительный адрес электронной почты' для поля Повторите адрес эл. почты не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при вводе менее 10х символов в поле Номер телефона")
    public Feedback checkErrorMinLengthPhone() {
        waitEnableElement(errorMinLengthPhone, "Сообщение 'Вы должны ввести не менее 10 символов' для поля Номер телефона не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка загрузки файла с размером 0кб")
    public Feedback checkErrorMinLengthFile() {
        waitEnableElement(errorMinLengthFile, "Сообщение 'Загружен файл размером 0 Kб, пожалуйста, проверьте загружаемые файлы' для поля Прикрепить файл не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка вводе email не по формату")
    public Feedback checkErrorFormatEmail() {
        waitEnableElement(errorLengthEmail, "Сообщение 'Вы должны указать действительный адрес электронной почты' для поля Адрес эл. почты не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при незаполненом поле Имя соавтора")
    public Feedback checkErrorCoAuthorName() {
        waitEnableElement(coAuthorErrorName, "Сообщение 'Поле обязательно для заполнения' для поля Имя соавтора не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при незаполненом поле Фамилия соавтора")
    public Feedback checkErrorCoAuthorSurname() {
        waitEnableElement(coAuthorErrorSurname, "Сообщение 'Поле обязательно для заполнения' для поля Фамилия соавтора не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при вводе менее 2х символов в поле соавтор Имя")
    public Feedback checkErrorLengthCoAuthorName() {
        waitEnableElement(errorLengthSoAuthorName, "Сообщение 'Вы должны ввести не менее 2х символов' для поля соавтор Имя не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при вводе менее 3х символов в поле соавтор Фамилия")
    public Feedback checkErrorLengthCoAuthorSurname() {
        waitEnableElement(errorLengthSoAuthorSurname, "Сообщение 'Вы должны ввести не менее 3х символов' для поля соавтор Фамилия не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка вводе соавтор email не по формату")
    public Feedback checkErrorFormatCoAuthorEmail() {
        waitEnableElement(errorLengthSoAuthorEmail, "Сообщение 'Вы должны указать действительный адрес электронной почты' для поля соавтор Адрес эл. почты не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка загрузки файла с размером более 10mb")
    public Feedback checkErrorBigFile() {
        waitEnableElement(errorBigLengthFile, "Сообщение 'Превышен максимальный размер файлов' для поля Прикрепить файл не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка загрузки файла без расширения")
    public Feedback checkErrorFileWithoutFormat() {
        waitEnableElement(errorFileWithoutFormat, "Сообщение 'Загружен файл без расширения, проверьте загружаемые файлы' для поля Прикрепить файл не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются обращение отправлено")
    public Feedback checkaSuccessfullyAppealSent() {
        waitEnableElement(appealSent, "Обращение не отправлено. Всплывающее окно с текстом 'Обращение отправлено' не появилось");
        return this;
    }

    @Step(value = "Нажимаем чекбокс Отчество отсутствует")
    public Feedback clickCheckBoxNoMiddleName() {
        click(middleNameCheckBox);
        return this;
    }

    @Step(value = "Нажимаем чекбокс Принимаю условия Пользовательского соглашения")
    public Feedback clickCheckBoxCustomMessage() {
        click(applayCustomMessage);
        return this;
    }

    @Step(value = "Удаляем 2 соавтор")
    public Feedback delete2CoAuthor() {
        click(delete2CoAuthor);
        return this;
    }

    @Step(value = "Проеверяем что нет ошибки после прикрепления файла")
    public Feedback errorMessageAttachNoExist() {
        waitCountElements(By.xpath("//label[@for='field237.field369' and contains(text(),'Загружен файл недопустимого формата, проверьте загружаемые файлы')]"), 0, "Прикрепленный файл не удален", 2);
        return this;
    }

    @Step(value = "Проеверяем что форма отправлена и нет ошибок")
    public Feedback errorMessageСapchaError() {
        waitCountElements(By.xpath("//label[@for='field237.field381' and contains(text(),'Неправильный код проверки')]"), 0, "Форма не отправлена, некоторые поля заполненны не верно", 2);
        return this;
    }

    public Feedback checkErrorMinLengthPhoneNoExist() {
        waitCountElements(By.xpath("//label[@for='field237.field303' and contains(text(),'Вы должны ввести не менее 10 символов')]"), 0, "В поле Номер телефона можно ввести более 64 символов", 2);
        return this;
    }
}
