package DriverBuilder;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.HashMap;
import java.util.Map;

public class BrowserFactory {
  /* private final static Map<BrowserType, IWebDriverBuilder> browsersMap;

   static {
      browsersMap = new HashMap() {
         {
            put(BrowserType.Chrome, new ChromeDriverBuilder());
          //  put(BrowserType.FireFox, new FirefoxDriverBuildr());
         }
      };
   }
*/
/*   public WebDriver createDriver(BrowserType browserType) {
      return ChromeDriverBuilder.GetDriver();
   }*/
}
