package Pages.CreateNewNews;

import DriverBuilder.Driver;
import Exceptions.AutotestError;
import Objects.News;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.Arrays;
import java.util.HashMap;

import static Helper.Elements.sendText;
import static Helper.Elements.waitEnableElement;
import static Helper.Helper.getStorage;

public class SEOTab extends Menu {

   @FindBy(xpath = "//*[@class='form-group']/input[@placeholder='Начните вводить...']")
   private WebElement title;

   @FindBy(xpath = "//*[@class='form-group']//textarea[@placeholder='Перечислите ключевые слова']")
   private WebElement keyWords;

   @FindBy(xpath = "//*[@class='form-group']//textarea[@placeholder='Укажите описание']")
   private WebElement description;

   public SEOTab() {
      PageFactory.initElements(Driver.getWebDriver(), this);
      waitEnableElement(title);
   }

   @Step(value = "Заполняем поле заголовок")
   public SEOTab sentTitle(String titleText) {
      sendText(title, titleText);
      return this;
   }

   @Step(value = "Заполняем поле ключевые слова")
   public SEOTab sentKeyWords(String keyWordsText) {
      sendText(keyWords, keyWordsText);
      return this;
   }

   @Step
   public SEOTab sentDescription(String descriptionText) {
      sendText(description, descriptionText);
      return this;
   }

   @Step(value = "Проверяем поле заголовок")
   public SEOTab checkTitle(News news) {
      String curentTitle = getNameValue(By.xpath("//*[@class='form-group']/input[@placeholder='Начните вводить...']"));
      if (!news.getHeadline().equals(curentTitle)) {
         new AutotestError("Заголовок на вкладке SEO отличается от заголовка на вкладке Основное");
      }
      return this;
   }

   @Step(value = "Изменяем значение поля Заголовок")
   public SEOTab changeTitle(String news) {
      sentTitle(news);
      return this;
   }

   @Step(value = "Проверяем поле Ключевые слова")
   public SEOTab checkWordKeys(News news) {
      HashMap<String, String> keys = new HashMap<>();
      String itemMenu = getStorage("Пункты меню");
      String itemMenuNew = Arrays.asList(getStorage("Пункты меню").split("/")).get(itemMenu.split("/").length - 1).toLowerCase();
      String tags = getStorage("Теги").toLowerCase();
      //String source = getStorage("Источник").toLowerCase();
      keys.put("Пункты меню", itemMenuNew);
      keys.put("Теги", tags);
      //keys.put("Источник", source);

      String seoKeyWords = getNameValue(By.xpath("//*[@class='form-group']//textarea[@placeholder='Перечислите ключевые слова']")).toLowerCase();
      for (String key : keys.keySet()) {
         if (!seoKeyWords.contains(keys.get(key)))
            new AutotestError("На вкладке SOE в поле Ключевые слова, отсутствует обязательно слово '" + keys.get(key) + "' из значения поля '" + key + "' с вкладке Оснлвное");
      }
      return this;
   }

   private String getNameValue(By element) {
      JavascriptExecutor jse = (JavascriptExecutor) Driver.getWebDriver();
      return String.valueOf(jse.executeScript("return arguments[0].value;", waitEnableElement(element)));
   }
}
