package Pages.CreateNewNews;

import DriverBuilder.Driver;
import Objects.Tabs;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

import static Helper.Elements.*;
import static Helper.Helper.getNameValue;
import static org.openqa.selenium.By.xpath;

public class TabsTab extends Menu {

   @FindBy(xpath = "//button[text()='Добавить вкладку']")
   private WebElement addTab;

   @FindBy(xpath = "//input[@placeholder='Название вкладки']")
   private WebElement nameTab;

   public TabsTab() {
      PageFactory.initElements(Driver.getWebDriver(), this);
      waitEnableElement(addTab);
   }

   @Step(value = "Заполняем поле Заголовок вкладки")
   public TabsTab sentNameTab(String tabNameTxt) {
      sendText(nameTab, tabNameTxt);
      return this;
   }

   @Step(value = "Заполняем поле Текст вкладки")
   public TabsTab sentTextTab(String tabTxt) {
      Driver.getWebDriver().switchTo().defaultContent().switchTo().frame(1);
      sendText(xpath("(//*[@id='tinymce'])[1]"), tabTxt);
      Driver.getWebDriver().switchTo().defaultContent();
      return this;
   }

   @Step(value = "Добавляем новую вкладку для новости")
   public TabsTab addNewTab(Tabs tabs) {
      click(addTab);
      sentNameTab(tabs.getNameTab());
      sentTextTab(tabs.getTextTab());
      return this;
   }

   @Step(value = "Добавляем несколько новых вкладок")
   public TabsTab addSeveralTabs(List<Tabs> tabs) {
      int i = 0;
      for (Tabs tab : tabs) {
         click(addTab);
         waitCountElements(By.xpath("//*[@placeholder='Название вкладки']"), ++i);
         sendText(By.xpath("(//*[@placeholder='Название вкладки'])[last()]"), tab.getNameTab());
         Driver.getWebDriver().switchTo().defaultContent().switchTo().frame(i);
         sendText(xpath("(//*[@id='tinymce'])[1]"), tab.getTextTab());
         Driver.getWebDriver().switchTo().defaultContent();
      }
      return this;
   }

   @Step(value = "Удаляем вкладку")
   public TabsTab deleteTab(Tabs tabs) {
      waitCountElementsToBeMoreT(By.xpath("//*[@placeholder='Название вкладки']"), 1, "На странице всего одна вкладка а должно быть больше");
      int size = Driver.getWebDriver().findElements(By.xpath("//*[@placeholder='Название вкладки']")).size();
      for (int i = 1; i <= size; i++) {
         if (getNameValue(By.xpath("(//*[@placeholder='Название вкладки'])")).equals(tabs.getNameTab())) {
            click(By.xpath("//div/button[contains(@class, 'btn-secondary')]/i[contains(@class,'fa-trash')]"));
            return this;
         }
      }
      return this;
   }

   @Step(value = "Изменяем Заголовок и Текст вкладки")
   public TabsTab changeExistTab(Tabs firstTabs, Tabs secondTabs) {
      waitCountElementsToBeMoreT(By.xpath("//*[@placeholder='Название вкладки']"), 0, "На странице всего одна вкладка а должно быть больше");
      int size = Driver.getWebDriver().findElements(By.xpath("//*[@placeholder='Название вкладки']")).size();
      for (int i = 1; i <= size; i++) {
         if (getNameValue(By.xpath("(//*[@placeholder='Название вкладки'])[" + i + "]")).equals(firstTabs.getNameTab())) {
            sendText(By.xpath("(//*[@placeholder='Название вкладки'])[" + i + "]"), secondTabs.getNameTab());
            Driver.getWebDriver().switchTo().defaultContent().switchTo().frame(i);
            sendText(xpath("(//*[@id='tinymce'])[1]"), secondTabs.getTextTab());
            Driver.getWebDriver().switchTo().defaultContent();
            return this;
         }
      }
      return this;
   }

   public TabsTab upTabOnTop(Tabs secondTabs) {
      waitCountElementsToBeMoreT(By.xpath("//*[@placeholder='Название вкладки']"), 0, "На странице всего одна вкладка а должно быть больше");
      int size = Driver.getWebDriver().findElements(By.xpath("//*[@placeholder='Название вкладки']")).size();
      for (int i = 1; i <= size; i++) {
         if (getNameValue(By.xpath("(//*[@placeholder='Название вкладки'])[" + i + "]")).equals(secondTabs.getNameTab())) {
            click(By.xpath("((//*[@placeholder='Название вкладки'])[" + i + "]/following::button[contains(@class,'btn-secondary')])[1]"));
            return this;
         }
      }
      return this;
   }
}

