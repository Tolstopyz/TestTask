package Pages;

import DriverBuilder.Driver;
import Helper.Props;
import Pages.CreateNewNews.Menu;
import Pages.CreateNewNews.PageSettingTab;
import io.qameta.allure.Step;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static Helper.Elements.*;

public class Feedback {

    public Feedback() {
        PageFactory.initElements(Driver.getWebDriver(), this);
        waitEnableElement(appealText);
    }

    @FindBy(xpath = "//*[@class='col-sm-8']//input[@id='field237.field255']")
    private WebElement surname;

    @FindBy(xpath = "//*[@class='col-sm-8']//input[@id='field237.field261']")
    private WebElement name;

    @FindBy(xpath = "//*[@class='col-sm-8']//input[@id='field237.field267']")
    private WebElement middleName;

    @FindBy(xpath = "//*[@class='col-sm-8']//input[@id='field237.field279']")
    private WebElement nameCompany;

    @FindBy(xpath = "//*[@class='col-sm-8']//input[@id='field237.field291']")
    private WebElement email;

    @FindBy(xpath = "//*[@class='col-sm-8']//input[@id='field237.field297']")
    private WebElement replayEmail;

    @FindBy(xpath = "//*[@class='col-sm-8']//input[@id='field237.field303']")
    private WebElement phoneNumber;

    @FindBy(xpath = "//*[@class='form-group']//button[contains(@class,'btn-transparent--black')]")
    private WebElement buttonAdd;

    @FindBy(xpath = "//*[@class='col-sm-12']//textarea[@id='field237.field351']")
    private WebElement appealText;

    @FindBy(xpath = "//*[@class='form-control-wrapper2']/input[@type='button']")
    private WebElement buttonSent;

    @FindBy(xpath = "//label[@for='field237.field261' and contains(text(),'Поле обязательно для заполнения')]")
    private WebElement errorName;

    @FindBy(xpath = "//label[@for='field237.field255' and contains(text(),'Поле обязательно для заполнения')]")
    private WebElement errorSurname;

    @FindBy(xpath = "//label[@for='field237.field291' and contains(text(),'Поле обязательно для заполнения')]")
    private WebElement errorEmail;

    @FindBy(xpath = "//label[@for='field237.field297' and contains(text(),'Поле обязательно для заполнения')]")
    private WebElement errorReplayEmail;

    @FindBy(xpath = "//label[@for='field237.field351' and contains(text(),'Поле обязательно для заполнения')]")
    private WebElement errorAppealText;

    @FindBy(xpath = "//label[@for='field237.field297' and contains(text(),'Значения не совпадают')]")
    private WebElement errorReplayEmailValues;

    @FindBy(xpath = "//input[@type='file']")
    private WebElement attache;

    @Step(value = "Заполняем поле Имя")
    public Feedback sentName(String text) {
        sendText(name, text);
        return this;
    }

    @Step(value = "Заполняем поле Фамилия")
    public Feedback sentSurname(String text) {
        sendText(surname, text);
        return this;
    }

    @Step(value = "Заполняем поле Отчество")
    public Feedback sentMiddleName(String text) {
        sendText(middleName, text);
        return this;
    }

    @Step(value = "Заполняем поле Адрес эл. почты")
    public Feedback sentEmail(String text) {
        sendText(email, text);
        return this;
    }

    @Step(value = "Заполняем поле Повторите адрес эл. почты")
    public Feedback sentReplayEmail(String text) {
        sendText(replayEmail, text);
        return this;
    }

    @Step(value = "Заполняем поле Номер телефона")
    public Feedback sentPhoneNumber(String text) {
        sendText(phoneNumber, text);
        return this;
    }

    @Step(value = "Нажимаем кнопку Добавить")
    public Feedback clickButtonAdd() {
        click(buttonAdd);
        return this;
    }

    @Step(value = "Нажимаем кнопку Отправить")
    public Feedback clickButtonSent() {
        click(buttonSent);
        return this;
    }

    @Step(value = "Заполняем поле Текст обращения")
    public Feedback sentAppealText(String text) {
        sendText(appealText, text);
        return this;
    }

    @Step(value = "Прикрепляет файл")
    public Feedback attachFile(String fileName) {
        sendText(attache, fileName);
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при незаполненом поле Имя")
    public Feedback checkErrorName() {
        waitEnableElement(errorName, "Сообщение 'Поле обязательно для заполнения' для поля Имя не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при незаполненом поле Фамилия")
    public Feedback checkErrorSurname() {
        waitEnableElement(errorSurname, "Сообщение 'Поле обязательно для заполнения' для поля Фамилия не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при незаполненом поле Email")
    public Feedback checkErrorEmail() {
        waitEnableElement(errorEmail, "Сообщение 'Поле обязательно для заполнения' для поля Email не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при незаполненом поле повтор Email")
    public Feedback checkErrorReplayEmail() {
        waitEnableElement(errorReplayEmail, "Сообщение 'Поле обязательно для заполнения' для поля Повтор Email не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при незаполненом поле Текст обращения")
    public Feedback checkErrorAppealText() {
        waitEnableElement(errorAppealText, "Сообщение 'Поле обязательно для заполнения' для поля Текст обращения не появилось");
        return this;
    }

    @Step(value = "Проверяем, что появляются ошибка при несовпадения значения в поле Повторите адрес эл. почты")
    public Feedback checkErrorReplayEmailValues() {
        waitEnableElement(errorReplayEmailValues, "Сообщение 'Значения не совпадают' для поля Повторите адрес эл. почты не появилось");
        return this;
    }
}
