package Exceptions;

public class TestNgRunException extends RuntimeException {

   public TestNgRunException(String msg) {
      super(msg);
   }
}
