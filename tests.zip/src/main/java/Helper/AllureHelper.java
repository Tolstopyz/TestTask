package Helper;

import io.qameta.allure.Attachment;
import org.apache.log4j.Logger;

import java.nio.charset.Charset;

public class AllureHelper {

   private AllureHelper() {
      throw new IllegalAccessError("Utility class");
   }

   private static final Logger logger = Logger.getLogger(AllureHelper.class);

   @Attachment(value = "Attachment", type = "text/plain")
   public static byte[] stringToLog(String txt) {
      return txt.getBytes(Charset.forName("utf-8"));
   }

   @Attachment(type = "text/plain", value = "Request data")
   private String attachRequest(String url, String params) {
      return "Request url:" + url + "\n" + "PARAMS:" + params;
   }

   @Attachment(type = "text/plain", value = "Error data")
   private String attachError(String error) {
      return error;
   }

   @Attachment(value = "SQL Request Result", type = "text/html")
   public static byte[] addHtmlPageToReport(String string) {
      return string.getBytes(Charset.forName("utf-8"));
   }

   @Attachment(value = "Input Parameters", type = "text/html")
   public static byte[] addDataTableToReport(String string) {
      return string.getBytes(Charset.forName("utf-8"));
   }

}
