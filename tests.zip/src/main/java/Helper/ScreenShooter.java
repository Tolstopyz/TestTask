package Helper;

import DriverBuilder.Driver;
import io.qameta.allure.Attachment;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

public class ScreenShooter {

   private static final Logger Log = Logger.getLogger(ScreenShooter.class);

   @Attachment(type = "image/jpg", value = "Screenshot")
   public static byte[] capturingFullPage() {
      String url = Driver.getWebDriver().getCurrentUrl();
      Log.info("Сохраняем скриншот для страницы URL " + url);
      Screenshot screenshot = new AShot()
            .shootingStrategy(ShootingStrategies.viewportPasting(100))
            .takeScreenshot(Driver.getWebDriver());
      final BufferedImage image = screenshot.getImage();
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      try {
         ImageIO.write(image, "jpg", byteArrayOutputStream);
      } catch (IOException e) {
         Error.autotestError("Невозможно сохраниить картинку в byteArrayOutputStream " + e.getMessage());
      }
      return byteArrayOutputStream.toByteArray();
   }

   @Attachment(type = "image/jpg", value = "Screenshot")
   public static byte[] capturingWebElement(WebElement webElement) {
      Log.info("Сохраняем скриншот для WebElement");
      Screenshot screenshot = new AShot()
            .shootingStrategy(ShootingStrategies.viewportPasting(500))
            .takeScreenshot(Driver.getWebDriver(), webElement);
      final BufferedImage image = screenshot.getImage();
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      try {
         ImageIO.write(image, "jpg", byteArrayOutputStream);
      } catch (IOException e) {
         Error.autotestError("Невозможно сохраниить картинку в byteArrayOutputStream " + e.getMessage());
      }
      return byteArrayOutputStream.toByteArray();
   }

   private static void saveImage(BufferedImage bufferedImage, String pathToSaveScreen) {
      try {
         ImageIO.write(bufferedImage, "jpg", new File(pathToSaveScreen));
      } catch (IOException e) {
         Error.autotestError("Невозможно сохраниить скриншот элемента в byteArrayOutputStream " + pathToSaveScreen);
      }
   }

/*   private static String getDate() {
      DateFormat dataFormat = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
      Date currentDate = new Date();
      return dataFormat.format(currentDate);
   }*/
}
