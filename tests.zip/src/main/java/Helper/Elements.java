package Helper;

import DriverBuilder.Driver;
import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;

import static Helper.Error.autotestError;

public class Elements {

   private static final Logger LOG = Logger.getLogger(Elements.class);
   private static final Integer TIMEOUT = 20;

   private static final long DEFAULT_DELAY_TIMEOUT = (long) 1500;

   public static void click(By by) {
      try {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.elementToBeClickable(by)).click();
      } catch (StaleElementReferenceException ex) {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.elementToBeClickable(by)).click();
      } catch (TimeoutException ex) {
         autotestError("Невозможно кликнуть по элементу с локатором " + by);
      }
   }

   public static void click(WebElement webElement) {
      long startTime = System.currentTimeMillis();
      long endTime = startTime + (long) 200000;
      while (System.currentTimeMillis() < endTime) {
         try {
            new WebDriverWait(Driver.getWebDriver(), TIMEOUT).ignoring(WebDriverException.class).until(ExpectedConditions.elementToBeClickable(webElement))
                  .click();
            return;
         } catch (WebDriverException ex) {
            sleep(DEFAULT_DELAY_TIMEOUT);
         }
      }
      autotestError("Невозможно кликнуть по элементу с локатором " + webElement);
   }

   public static void click(WebElement webElement, String textError) {
      long startTime = System.currentTimeMillis();
      long endTime = startTime + (long) 200000;
      while (System.currentTimeMillis() < endTime) {
         try {
            new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.elementToBeClickable(webElement))
                  .click();
            return;
         } catch (WebDriverException ex) {
            sleep(DEFAULT_DELAY_TIMEOUT);
         }
      }
      autotestError(textError);
   }

   public static void sendText(By by, String text) {
      try {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.visibilityOfElementLocated(by)).clear();
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.visibilityOfElementLocated(by)).sendKeys(text);
      } catch (StaleElementReferenceException ex) {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.visibilityOfElementLocated(by)).sendKeys(text);
      } catch (TimeoutException ex) {
         autotestError("Не удалось ввести текст по локатору " + by);
      }
   }

   public static void sendText(WebElement webElement, String text) {
      try {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.visibilityOf(webElement)).clear();
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.visibilityOf(webElement)).sendKeys(text);
      } catch (StaleElementReferenceException ex) {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.visibilityOf(webElement)).sendKeys(text);
      } catch (TimeoutException ex) {
         autotestError("Не удалось ввести текст для элемента " + webElement.getText());
      }
   }

   public static void waitText(By by, String text) {
      try {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.textToBe(by, text));
      } catch (TimeoutException ex) {
         autotestError("Текст элемента не соответсвует ожидаемому " + text);
      }
   }

   public static WebElement waitEnableElement(By by) {
      try {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.visibilityOfElementLocated(by));
      } catch (StaleElementReferenceException ex) {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.visibilityOfElementLocated(by));
      } catch (TimeoutException ex) {
         autotestError("В течение " + TIMEOUT + " секунд, элемент с локатором " + by + " не стал доступен");
      }
      return Driver.getWebDriver().findElement(by);
   }

   public static WebElement waitEnableElement(By by, String error, int time) {
      try {
         new WebDriverWait(Driver.getWebDriver(), time).until(ExpectedConditions.visibilityOfElementLocated(by));
      } catch (StaleElementReferenceException ex) {
         new WebDriverWait(Driver.getWebDriver(), time).until(ExpectedConditions.visibilityOfElementLocated(by));
      } catch (TimeoutException ex) {
         autotestError(error);
      }
      return Driver.getWebDriver().findElement(by);
   }

   public static void waitEnableElement(WebElement webElement) {
      try {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.elementToBeClickable(webElement));
      } catch (StaleElementReferenceException ex) {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.elementToBeClickable(webElement));
      } catch (TimeoutException ex) {
         autotestError("В течение " + TIMEOUT + " секунд, элемент с локатором " + webElement + " не стал доступен");
      }
   }

   public static void waitEnableElement(WebElement webElement, String errorText) {
      try {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.elementToBeClickable(webElement));
      } catch (StaleElementReferenceException ex) {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.elementToBeClickable(webElement));
      } catch (TimeoutException ex) {
         autotestError(errorText);
      }
   }

   public static Boolean waitElementExist(By by) {
      try {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.visibilityOfElementLocated(by));
         return true;
      } catch (StaleElementReferenceException ex) {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.elementToBeClickable(by));
         return true;
      } catch (TimeoutException ex) {
         return false;
      }
   }

   public static void waitTitle(String title) {
      try {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.titleIs(title));
      } catch (TimeoutException ex) {
         autotestError("Title страници не соответсвует ожидаемому: " + title);
      }
   }

   public static boolean checkTitle(String title) {
      try {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.titleIs(title));
         return true;
      } catch (TimeoutException ex) {
         return false;
      }
   }

   public static void waitCountElements(By by, int count) {
      try {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.numberOfElementsToBe(by, count));
      } catch (TimeoutException ex) {
         autotestError("Количество элементов по локатору " + by + " не соответсвует заданному " + count);
      }
   }

   public static void waitCountElements(By by, int count, String erroeMsg, int time) {
      try {
         new WebDriverWait(Driver.getWebDriver(), time).until(ExpectedConditions.numberOfElementsToBe(by, count));
      } catch (TimeoutException ex) {
         autotestError(erroeMsg);
      }
   }

   public static void waitCountElementsToBeMoreT(By by, int count, String erroeMsg) {
      try {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.numberOfElementsToBeMoreThan(by, count));
      } catch (TimeoutException ex) {
         autotestError(erroeMsg);
      }
   }

   public static void checkContainsUrl(String url) {
      try {
         new WebDriverWait(Driver.getWebDriver(), TIMEOUT).until(ExpectedConditions.urlContains(url));
      } catch (TimeoutException ex) {
         autotestError("URL не содержит: " + url);
      }
   }

   public static void waitNewTabAndSwitch() {
      LOG.info("Зашли в метод waitNewTabAndSwitch");
      long startTime = System.currentTimeMillis();
      long endTime = startTime + (long) 100000;
      LOG.info("Начинаем ждать появления новой вкладки и переключаемся на нее");
      while (System.currentTimeMillis() < endTime) {
         if (Driver.getWebDriver().getWindowHandles().size() >= 2) {
            ArrayList<String> tabs = new ArrayList<>(Driver.getWebDriver().getWindowHandles());
            Driver.getWebDriver().switchTo().window(tabs.get(1));
            LOG.info("Переключились на новую вкладку");
            return;
         } else
            sleep(DEFAULT_DELAY_TIMEOUT);
      }
      autotestError("Новая вкладка не открылась");
   }

   private static void sleep(long time) {
      try {
         Thread.sleep(time);
      } catch (Exception e) {
         Thread.currentThread().interrupt();
         autotestError(e.getMessage());
      }
   }
}
