package Feedback;

import DriverBuilder.Driver;
import Smoke.BaseTests;
import org.apache.log4j.Logger;
import org.testng.annotations.BeforeTest;

public class BaseFeedbackTests {

    protected static final Logger LOG = Logger.getLogger(BaseTests.class);

    @BeforeTest()
    public void before() {
        Driver.getWebDriver().navigate().to("http://guip:guip@ui.mosreg.aismo.ru/feedback#step1");
    }
}
