package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class AttachOver10mb extends BaseFeedbackTests {
    @Test(description = "Пользоватль прикрепляет файлы более 10 mb")
    public void attachBigFile() {
        LOG.info("***** Пользоватль заполняет все поля кроме Email *****");
        new Feedback().sentName("Антон").sentSurname("Петров").sentName("anton@mail.ru").sentReplayEmail("anton@mail.ru").sentAppealText("Текст обращения от Антона").attachFile("C:\\Windows\\RtlExUpd.dll").clickButtonSent();
    }
}
