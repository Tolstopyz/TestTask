package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckName extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет все обязательные поля кроме Имя")
    public void addFeedbackWithoutName() {
        LOG.info("***** Пользоватль заполняет все поля кроме Имя *****");
        new Feedback().sentSurname("Петров").sentEmail("anton@mail.ru").sentReplayEmail("anton@mail.ru").sentAppealText("Текст обращения от Антона").clickButtonSent().checkErrorName();
    }
}
