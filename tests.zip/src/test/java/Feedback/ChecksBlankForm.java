package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class ChecksBlankForm extends BaseFeedbackTests {
    @Test(description = "Пользоватль нажимает кнопку Отправить без заполненых полей")
    public void addFeedbackWithoutFields() {
        LOG.info("***** Пользоватль не заполнчет поля и нажимает кнопку Отправить *****");
        new Feedback().clickButtonSent().checkErrorName().checkErrorSurname().checkErrorEmail().checkErrorReplayEmail().checkErrorAppealText();
    }
}
