package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class ChecksSurname extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет все обязательные поля кроме Фамилия")
    public void addFeedbackWithoutSurname() {
        LOG.info("***** Пользоватль заполняет все поля кроме Фамилия *****");
        new Feedback().sentName("Антон").sentEmail("anton@mail.ru").sentReplayEmail("anton@mail.ru").sentAppealText("Текст обращения от Антона").clickButtonSent().checkErrorSurname();
    }
}
