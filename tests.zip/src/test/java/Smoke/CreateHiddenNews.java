package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import Pages.CreateNewNews.MainTab;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static Helper.Helper.closeTabAndSwitchMainWindow;
import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.afterHiddenNews;

public class CreateHiddenNews extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Скрыто");

   @Test(description = "Пользователь скрывает созданную новость")
   public void addHiddenNews() {
      LOG.info("***** Запускаем тест Пользователь скрывает созданную новость *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            clickSave().
            clickOnSite().
            checkCorrectBodyTitle(testNews);
      closeTabAndSwitchMainWindow();
      new MainTab().
            goToListMaterials().
            checkStatusNewsHidden(testNews);
   }

   @AfterMethod
   public void after() {
      afterHiddenNews(testNews);
   }
}
