package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.deleteNewsWithoutClose;

public class EventDate extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   private String result = "Главная / Сейчас в работе / Мероприятия";

   @Test(description = "При заполнении поля Дата события появляется пункт Главная/Сейчас в работе/Мероприятия")
   public void addHiddenNews() {
      LOG.info("***** Запускаем тест При заполнении поля Дата события появляется пункт Главная/Сейчас в работе/Мероприятия *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            goToEvent().
            sentDateEvent().
            clickSave().
            goToMain().
            checkFieldItemsMenu(result);
   }

   @AfterTest
   public void after() {
      deleteNewsWithoutClose(testNews);
   }

}
