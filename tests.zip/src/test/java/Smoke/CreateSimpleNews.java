package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.deleteNews;

public class CreateSimpleNews extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(), "Текст для проверки добавления новых новостей",
         "Опубликовано");

   @Test(description = "Простое создание новости")
   public void addSimpleNews() {
      LOG.info("***** Запускаем тест Простое создание новости *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            clickSave().
            clickOnSite().
            checkCorrectNewNews(testNews);
   }

   @AfterTest
   public void after() {
      deleteNews(testNews);
   }
}
