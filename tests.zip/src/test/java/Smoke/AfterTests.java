package Smoke;

import DriverBuilder.Driver;
import Objects.News;
import Pages.Content.ListMaterials;
import Pages.CreateNewNews.Menu;
import org.apache.log4j.Logger;

import static Helper.Helper.closeTabAndSwitchMainWindow;

public class AfterTests {
   private static final Logger LOG = Logger.getLogger(AfterTests.class);

   public static void afterAddNewsTitleUrl(News news) {
      LOG.info("Зашли в метод afterAddNewsTitleUrl");
      try {
         closeTabAndSwitchMainWindow();
         new Menu().goToMain().goToListMaterials().deleteNews(news.getHeadline());
         Driver.destroy();
         return;
      } catch (AssertionError e) {
         Driver.destroy();
      }
   }

   public static void afterOtherTests() {
      LOG.info("Зашли в метод afterOtherTests");
      Driver.destroy();
   }

   public static void afterHiddenNews(News news) {
      LOG.info("Зашли в метод afterHiddenNews");
      try {
         new ListMaterials().deleteNews(news.getHeadline());
         Driver.destroy();
         return;
      } catch (AssertionError e) {
         Driver.destroy();
      }
   }

   public static void deleteNews(News news) {
      LOG.info("Зашли в метод deleteNews");
      try {
         closeTabAndSwitchMainWindow();
         new Menu().goToListMaterials().deleteNews(news.getHeadline());
         Driver.destroy();
         return;
      } catch (AssertionError e) {
         Driver.destroy();
      }
   }

   public static void deleteNewsFromListMaterials(News news) {
      try {
         new ListMaterials().deleteNews(news.getHeadline());
         Driver.destroy();
         return;
      } catch (AssertionError e) {
         Driver.destroy();
      }
   }

   public static void deleteNewsWithoutClose(News news) {
      try {
         new Menu().goToListMaterials().deleteNews(news.getHeadline());
      } catch (AssertionError e) {
         LOG.info("Поймали исключение в методе deleteNewsWithoutClose: " + e.toString());
         Driver.destroy();
         return;
      }
      Driver.destroy();
   }

   public static void closePage() {
      LOG.info("Зашли в метод closePage");
      Driver.destroy();
   }

}
