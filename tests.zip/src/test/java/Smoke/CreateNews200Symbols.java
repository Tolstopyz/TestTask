package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Smoke.AfterTests.deleteNews;

public class CreateNews200Symbols extends BaseTests {

   private News testNews = new News(
         "Свидетельство о регистрации Эл № ФС77-57640 Учредитель: Федеральное государственное унитарное предприятие Международное информационное агентство Россия сегодня (МИА Россия сегодня). Правила использования материалов",
         "Текст для проверки добавления новых новостей",
         "Опубликовано");

   @Test(description = "Создание новости с заголовком длинее 200 символов")
   public void addNews200Symbols() {
      LOG.info("***** Запускаем тест Создание новости с заголовком длинее 200 символов *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            clickSave().
            clickOnSite().
            checkCorrectNewNews(testNews);
   }

   @AfterTest
   public void deleteCreatedNews() {
      deleteNews(testNews);
   }
}
