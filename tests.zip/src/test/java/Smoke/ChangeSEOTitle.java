package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.deleteNews;

public class ChangeSEOTitle extends BaseTests {

    private News testNews = new News(
            getRandomHeadline(),
            "Опубликовано");

    private String titleSeo = "Change SEO on Title";

    @Test(description = "Заголовок не изменится если поменять его на вкладке SEO")
    public void сhangeSEO() {
        LOG.info("***** Запускаем тест Заголовок не изменится если поменять его на вкладке SEO *****");
        new AuthorizationPage().
                login().
                createNews().
                createNewNews(testNews).
                goToSeo().
                checkTitle(testNews).
                changeTitle(titleSeo).
                goToMain().
                checkTitle(testNews).
                clickSave().
                clickOnSite().
                checkBodyTitle(testNews);
    }

    @AfterTest
    public void after() {
        deleteNews(testNews);
    }
}
