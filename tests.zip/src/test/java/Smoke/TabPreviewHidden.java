package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.afterOtherTests;

public class TabPreviewHidden extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   @Test(description = "При создании новой новости поле Анонс скрыто")
   public void tabPreview() {
      LOG.info("***** Запускаем тест При создании новой новости поле Анонс скрыто *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            checkFieldPreviewHidden();
   }

   @AfterTest
   public void after() {
      afterOtherTests();
   }
}
