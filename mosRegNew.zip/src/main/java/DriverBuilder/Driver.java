package DriverBuilder;

import Exceptions.UnknownDriverTypeException;
import Helper.Props;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class Driver {
   private static WebDriver driver;
   private static BrowserType browserType;
   private static final Logger LOG = Logger.getLogger(Driver.class);

   private Driver() {
      throw new IllegalAccessError("Utility class");
   }

   public synchronized static WebDriver getWebDriver() {
      LOG.info("Зашли в метод getWebDriver");
      if (driver == null) {
         switch (Props.getProperty("browser")) {
            case "chrome":
               LOG.info("Создаем новый driver = chrome");
               browserType = BrowserType.Chrome;
               break;
            case "firefox":
               browserType = BrowserType.FireFox;
               break;
            default:
               throw new UnknownDriverTypeException("Unknown webDriver specified: " + Props.getProperty("browser"));
         }
         LOG.info("Возвращаем текущий driver");
         driver = new ChromeDriverBuilder().GetDriver();
      }
      return driver;
   }

   public static void destroy() {
      LOG.info("Зашли в метод destroy");
      LOG.info("Выполняем Driver.getWebDriver().quit()");
      Driver.getWebDriver().quit();
      LOG.info("Зануляем driver: driver = null");
      driver = null;
   }
}
