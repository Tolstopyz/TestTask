package Pages.CreateNewNews;

import DriverBuilder.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static Helper.Elements.waitEnableElement;

public class HelperTab extends Menu {

   @FindBy(xpath = "//*[@class='multiselect__tags']//span[contains(text(),'Начните вводить название министерства')]")
   private WebElement ministry;

   public HelperTab() {
      PageFactory.initElements(Driver.getWebDriver(), this);
      waitEnableElement(ministry);
   }
}
