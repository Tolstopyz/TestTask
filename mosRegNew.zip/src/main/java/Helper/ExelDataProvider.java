package Helper;

import Exceptions.ReadExcelFileException;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class ExelDataProvider {

   private XSSFWorkbook wb;

   public ExelDataProvider() {
      File src = new File("./src/main/resources/Data.xlsx");
      try (FileInputStream fileInputStream = new FileInputStream(src)) {
         wb = new XSSFWorkbook(fileInputStream);
      } catch (IOException e) {
         throw new ReadExcelFileException(e.getMessage());
      }
   }

   public String getStringDate(int sheetName, int row, int column) {
      return wb.getSheetAt(sheetName).getRow(row).getCell(column).getStringCellValue();
   }

   public String getStringDate(String sheetName, int row, int column) {
      return wb.getSheet(sheetName).getRow(row).getCell(column).getStringCellValue();
   }

   public double getNumericDate(String sheetName, int row, int column) {
      return wb.getSheet(sheetName).getRow(row).getCell(column).getNumericCellValue();
   }
}
