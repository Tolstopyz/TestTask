package runner;

import Config.Settings;
import Exceptions.TestNgRunException;
//import org.kohsuke.args4j.CmdLineException;
//import org.kohsuke.args4j.CmdLineParser;
import org.testng.TestNG;
import org.testng.xml.Parser;
import org.testng.xml.XmlSuite;

public class Runner {

 /*  protected TestNG testNG = new TestNG();
   private String testNgConfig;

   public static void main(String[] args) {
      new Runner(args).run();
   }

   public Runner(String[] args) {
      Settings settings = new Settings();
      CmdLineParser cmdLineParser = new CmdLineParser(settings);

      try {
         cmdLineParser.parseArgument(args);
         testNgConfig = settings.testNgPath;
      } catch (CmdLineException e) {
         System.err.println("Error:" + e.toString());
         cmdLineParser.printUsage(System.out);
      }
   }

   public void run() {
      try {
         XmlSuite xmlSuite = new Parser(testNgConfig).parseToList().get(0);
         this.testNG.setCommandLineSuite(xmlSuite);
         this.testNG.run();
      } catch (Exception ex) {
         throw new TestNgRunException("Error running Test NG suite " + ex.getMessage());
      }
   }*/
}
