package Objects;

import static Helper.Helper.getStorage;

public class News {

   private String headline;

   private Object menuItems;

   private Object rubricItems;

   private String textArea;

   private Object source;

   private Object tags;

   private Object topics;

   private Object similarNews;

   private Object authorities;

   private Object photoAlbum;

   private Object author;

   private String status;

   private String url;

   private final String RANDOM = "random";

  /* public News(String headline, String menuItems, String rubricItems, String author, String textArea, String source, String tags, String topics, String similarNews,
         String authorities,
         String photoAlbum, String status) {
      this.headline = headline;
      this.menuItems = menuItems;
      this.rubricItems = rubricItems;
      this.author = author;
      this.textArea = textArea;
      this.source = source;
      this.tags = tags;
      this.topics = topics;
      this.similarNews = similarNews;
      this.authorities = authorities;
      this.photoAlbum = photoAlbum;
      this.status = status;
   }

   public News(String headline, Integer menuItems, Integer rubricItems, Integer author, String textArea, Integer source, Integer tags, Integer topics, Integer similarNews,
         Integer authorities,
         Integer photoAlbum, String status) {
      this.headline = headline;
      this.menuItems = menuItems;
      this.rubricItems = rubricItems;
      this.author = author;
      this.textArea = textArea;
      this.source = source;
      this.tags = tags;
      this.topics = topics;
      this.similarNews = similarNews;
      this.authorities = authorities;
      this.photoAlbum = photoAlbum;
      this.status = status;
   }*/

   public News(String headline, String status) {
      this.headline = headline;
      this.status = status;
   }

   public News(String headline, String textArea, String status) {
      this.headline = headline;
      this.textArea = textArea;
      this.status = status;
      this.menuItems = RANDOM;
      this.rubricItems = RANDOM;
      this.author = RANDOM;
      this.source = RANDOM;
      this.tags = RANDOM;
      this.topics = RANDOM;
      this.similarNews = RANDOM;
      this.authorities = RANDOM;
      this.photoAlbum = RANDOM;
   }

   @Override
   public String toString() {
      return "Новость с полями: Заголовок: '" + getHeadline() + "', \n"
            + "Текст: '" + getTextArea() + "',"
            + "\nПункты меню: '" + getStorage("Пункты меню") + "',"
            + "\nРубрики: '" + getStorage("Рубрики") + "',"
            + "\nАвтор: '" + getStorage("Автор") + "',"
            + "\nИсточник: '" + getStorage("Источник") + "',"
            + "\nТеги: '" + getStorage("Теги") + "',"
            + "\nТемы: '" + getStorage("Темы") + "',"
            + "\nПохожие новости: '" + getStorage("Похожие новости") + "',"
            + "\nПерсоны и органы власти: '" + getStorage("Персоны и органы власти") + "'"
            + "\nФотоальбом: '" + getStorage("Фотоальбом") + "'"
            + "\nСтатус: '" + getStatusNews() + "'";
   }

   public String getHeadline() {
      return headline;
   }

   public Object getAuthor() {
      return author;
   }

   public Object getMenuItems() {
      return menuItems;
   }

   public Object getRubricItems() {
      return rubricItems;
   }

   public String getTextArea() {
      return textArea;
   }

   public Object getSource() {
      return source;
   }

   public Object getTags() {
      return tags;
   }

   public Object getTopics() {
      return topics;
   }

   public Object getSimilarNews() {
      return similarNews;
   }

   public Object getAuthorities() {
      return authorities;
   }

   public Object getPhotoAlbum() {
      return photoAlbum;
   }

   public Object getStatusNews() {
      return status;
   }

   public Object getUrl() {
      return url;
   }

}
