package Smoke;

import DriverBuilder.Driver;
import Helper.Props;
import org.apache.log4j.Logger;
import org.testng.annotations.BeforeTest;

public class BaseTests {

   protected static final Logger LOG = Logger.getLogger(BaseTests.class);

   @BeforeTest()
   public void before() {
      Driver.getWebDriver().navigate().to("http://guip:guip@" + Props.getProperty("host") + "/login");
   }
}
