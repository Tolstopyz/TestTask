package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.deleteNewsWithoutClose;

public class SetSource extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   private String source = "Управление пресс-службы губернатора и правительства Московской области";
   private String result = "Главная / Губернатор / Пресс-служба / Пресс-релизы";

   @Test(description = "При заполнении поля Источник Управление пресс-службы губернатора и правительства Московской области добавляется пункт Пресс-релизы")
   public void addTypeEventDate() {
      LOG.info("***** Запускаем тест При заполнении поля Источник Управление пресс-службы губернатора и правительства Московской области добавляется пункт Пресс-релизы*****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            sentSource(source).
            clickSave().
            goToMain().
            checkFieldItemsMenu(result);
   }

   @AfterTest
   public void after() {
      deleteNewsWithoutClose(testNews);
   }
}
