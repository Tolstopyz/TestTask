package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static Smoke.AfterTests.afterOtherTests;

public class CreateNewsEmptyHeadline extends BaseTests {
   private News testNews = new News(
         "",
         "Текст для проверки добавления новых новостей",
         "Опубликовано");

   @Test(description = "Создание новости с незаполненным полем Заголовок")
   public void addNewsEmptyHeadline() {
      LOG.info("***** Запускаем тест Создание новости с незаполненным полем Заголовок *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            clickSave().
            goToMain().
            checkErrorHeadlineField();
   }

   @AfterMethod
   public void after() {
      afterOtherTests();
   }

}
