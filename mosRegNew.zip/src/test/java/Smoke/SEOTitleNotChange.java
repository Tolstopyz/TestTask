package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import Pages.CreateNewNews.MainTab;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static Helper.Helper.closeTabAndSwitchMainWindow;
import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.deleteNewsWithoutClose;

public class SEOTitleNotChange extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   private String title = "Change Title";

   @Test(description = "При смене заголовка на вкладке Основно, заголовок в SEO не меняется")
   public void titleNotChange() {
      LOG.info("***** Запускаем тест При смене заголовка на вкладке Основно, заголовок в SEO не меняется *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            clickSave().
            clickOnSite().
            checkBodyTitle(testNews);
      closeTabAndSwitchMainWindow();
      new MainTab().
            goToMain().
            sentHeadline(title).
            clickSave().
            goToSeo().
            checkTitle(testNews);
   }

   @AfterMethod
   public void after() {
      deleteNewsWithoutClose(testNews);
   }
}
