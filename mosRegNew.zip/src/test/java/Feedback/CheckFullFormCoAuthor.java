package Feedback;

import Pages.Feedback;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Smoke.AfterTests.afterOtherTests;

public class CheckFullFormCoAuthor extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет все поля и добавляет соавторов")
    public void addFeedbackWithoutAppealText() {
        LOG.info("***** Пользоватль заполняет все поля и добавляет соавторов *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentMiddleName("Иванович")
                .sentNameCompany("Газпром")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentPhoneNumber("+79211111111")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonAddCoAuthor()
                .sentCoAuthorName("Артем")
                .sentCoAuthorSurname("Иванов")
                .sentCoAuthorEmail("mail@mail.com")
                .clickButtonAddCoAuthor()
                .sentCoAuthor2Name("Иван")
                .sentCoAuthor2Surname("Петров")
                .sentCoAuthor2MiddleName("Сергеевич")
                .sentCoAuthor2Email("mail@mail.com")
                .clickButtonSent()
                .checkaSuccessfullyAppealSent();
    }

}
