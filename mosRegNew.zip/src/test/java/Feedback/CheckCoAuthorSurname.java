package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckCoAuthorSurname extends BaseFeedbackTests {
    @Test(description = "Пользователь добавляет соавторов обращения но не заполняет поле Фамилия")
    public void addFeedbackWithoutName() {
        LOG.info("***** Пользователь добавляет соавторов обращения но не заполняет поле Фамилия *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonAddCoAuthor()
                .sentCoAuthorName("Артем")
                .clickButtonSent()
                .checkErrorCoAuthorSurname();
    }
}
