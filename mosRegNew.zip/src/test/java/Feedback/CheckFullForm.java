package Feedback;

import Pages.Feedback;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Smoke.AfterTests.afterOtherTests;

public class CheckFullForm extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет все поля формы")
    public void addFeedbackWithoutAppealText() {
        LOG.info("***** Пользоватль заполняет все поля формы *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentMiddleName("Иванович")
                .sentNameCompany("Газпром")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentPhoneNumber("+79211111111")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonSent()
                .checkaSuccessfullyAppealSent();
    }

    @AfterTest
    public void after() {
        afterOtherTests();
    }
}
