package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class RemovAttachFile extends BaseFeedbackTests {
    @Test(description = "Пользоватль удаляет прикрепленный файл")
    public void attachMinFile() {
        LOG.info("***** Пользоватль удаляет прикрепленный файл *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .attachFile("Skyeng_FAQ.docx")
                .clickButtonRemoveAttach();
    }
}
