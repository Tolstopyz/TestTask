package Pages.Content;

import DriverBuilder.Driver;
import Helper.Props;
import Objects.News;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static Helper.Elements.click;
import static Helper.Elements.waitEnableElement;

public class Basket {

   @FindBy(xpath = "//a[contains(text(),'Очистить корзину')]")
   private WebElement clearBasket;

   @FindBy(xpath = "//a[@href='http://ui.mosreg.aismo.ru/admin/basket/materials']")
   private WebElement removedMaterials;

   public Basket() {
      PageFactory.initElements(Driver.getWebDriver(), this);
      waitEnableElement(clearBasket);
   }

   @Step(value = "Нажимаем кнопку Удаленные материалы")
   public Basket clickRemovedMaterials() {
      click(waitEnableElement(By.xpath("//a[@href='http://" + Props.getProperty("host") + "/admin/basket/materials']")));
      return this;
   }

   @Step(value = "Удаленный матерьял переносится в корзину")
   public Basket checkNewsExistinBasket(News text) {
      return checkNewsExistinBasket(text.getHeadline());
   }

   @Step(value = "Удаленный матерьял переносится в корзину")
   public Basket checkNewsExistinBasket(String text) {
      WebElement linkHeader = waitEnableElement(By.xpath("//td[@class='w-25'][text()='" + text + "']"));
      waitEnableElement(linkHeader, "Удаленный матерьял с заголовком '" + text + "' не переносится в Корзину");
      return this;
   }

}
