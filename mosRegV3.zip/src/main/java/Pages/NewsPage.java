package Pages;

import Exceptions.AutotestError;
import Objects.News;
import Objects.Tabs;
import io.qameta.allure.Step;
import org.openqa.selenium.By;

import java.util.List;

import static Helper.Elements.*;
import static Helper.Helper.getStorage;

public class NewsPage {

   @Step(value = "Проверяем отображение созданной новости на сайте")
   public NewsPage checkCorrectNewNews(News news) {
      checkTitle(news.getHeadline());
      checkBodyTitle(news.getHeadline());
      checkAuthor(news.getAuthor());
      checkMainText(news.getTextArea());
      checkSource(news.getSource());
      checkTopics(news.getTopics());
      checkTags(news.getTags());
      checkSimilarNews(news.getSimilarNews());
      return this;
   }

   public NewsPage() {
      waitNewTabAndSwitch();
   }

   @Step(value = "Проверяем поле Заголовок и url")
   public void checkCorrectTitleAndUrl(News news, String url) {
      checkBodyTitle(news.getHeadline());
      checkContainsUrl(url);
   }

   @Step(value = "Проверяем поле Заголовок")
   public NewsPage checkBodyTitle(String text) {
      String locator = "//*[@class='common__h1-deco'][text()='" + text + "']";
      if (!waitElementExist(By.xpath(locator)))
         new AutotestError("Заголовок страницы не соответстует: " + text + ". Не найден элемент по локатору: " + locator);
      return new NewsPage();
   }

   @Step(value = "Проверяем поле Заголовок")
   public NewsPage checkBodyTitle(News text) {
      String txt = text.getHeadline();
      String locator = "//*[@class='common__h1-deco'][text()='" + txt + "']";
      if (!waitElementExist(By.xpath(locator)))
         new AutotestError("Заголовок страницы не соответстует: " + txt + ". Не найден элемент по локатору: " + locator);
      return new NewsPage();
   }

   @Step(value = "Проверяем поле Заголовок и закрываем страницу")
   public NewsPage checkCorrectBodyTitle(String text) {
      String locator = "//*[@class='common__h1-deco'][text()='" + text + "']";
      if (!waitElementExist(By.xpath(locator)))
         new AutotestError("Заголовок страницы не соответстует: " + text + ". Не найден элемент по локатору: " + locator);
      return new NewsPage();
   }

   @Step(value = "Проверяем поле Заголовок и закрываем страницу")
   public NewsPage checkCorrectBodyTitle(News text) {
      return checkCorrectBodyTitle(text.getHeadline());
   }

   @Step(value = "Проверяем поле Автор")
   public void checkAuthor(Object author) {
      String locator = (author instanceof String & "random".equals(author)) ?
            "//*[@class='colomns']//strong[text()='" + getStorage("Автор") + "']" :
            "//*[@class='colomns']//strong[text()='" + author + "']";
      if (!waitElementExist(By.xpath(locator)))
         new AutotestError("Автор новости не соответстует: " + author + ". Не найден элемент по локатору: " + locator);
   }

   @Step(value = "Проверяем основной текст")
   public void checkMainText(String text) {
      String locator = "//*[@id='content']//p[text()='" + text + "']";
      if (!waitElementExist(By.xpath(locator)))
         new AutotestError("Основной текст новости не соответстует: " + text + ". Не найден элемент по локатору: " + locator);
   }

   @Step(value = "Проверяем поле Источник")
   public void checkSource(Object text) {
      String locator = (text instanceof String & "random".equals(text)) ?
            "//*[@class='article__source']//a[text()='" + getStorage("Источник") + "']" :
            "//*[@class='article__source']//a[text()='" + text + "']";
      if (!waitElementExist(By.xpath(locator)))
         new AutotestError("Источник новости не соответстует: " + text + ". Не найден элемент по локатору: " + locator);
   }

   @Step(value = "Проверяем поле Темы")
   public void checkTopics(Object text) {
      String locator = (text instanceof String & "random".equals(text)) ?
            "//*[@class='article__source']/a[text()='" + getStorage("Темы") + "']" :
            "//*[@class='article__source']/a[text()='" + text + "']";
      if (!waitElementExist(By.xpath(locator)))
         new AutotestError("Темы новости не соответстует: " + getStorage("Темы") + ". Не найден элемент по локатору: " + locator);
   }

   @Step(value = "Проверяем поле Теги")
   public void checkTags(Object text) {
      String locator = (text instanceof String & "random".equals(text)) ?
            "//*[@class='tegs__right']/a[text()='" + getStorage("Теги") + "']" :
            "//*[@class='tegs__right']/a[text()='" + text + "']";
      if (!waitElementExist(By.xpath(locator)))
         new AutotestError("Теги новости на странице не соответстует: " + getStorage("Теги") + ". Не найден элемент по локатору: " + locator);
   }

   @Step(value = "Проверяем поле Похожие новости")
   public void checkSimilarNews(Object text) {
      String locator = (text instanceof String & "random".equals(text)) ?
            "//*[@class='brick6']//div[text()='" + getStorage("Похожие новости") + "']" :
            "///*[@class='brick6']//div[text()='" + text + "']";
      if (!waitElementExist(By.xpath(locator)))
         new AutotestError("Похожие новости: " + text + ". Не найден элемент по локатору: " + locator);
   }

   @Step(value = "Проверяем что новая вкладка появилас")
   public NewsPage checkTab(Tabs nameTab) {
      String name = nameTab.getNameTab();
      String locator = "//a[text()='" + name + "']";
      if (!waitElementExist(By.xpath(locator)))
         new AutotestError("Вкладка с названием: " + name + " не отображается на странице. Не найден элемент по локатору: " + locator);
      return new NewsPage();
   }

   @Step(value = "Проверяем что новые вкладки появились на сайте")
   public NewsPage checkTabsAndText(List<Tabs> nameTab) {
      for (Tabs tab : nameTab) {
         String locator = "//a[text()='" + tab.getNameTab() + "']";
         checkTab(tab);
         waitEnableElement(By.xpath(locator)).click();
         checkTextTab(tab);
      }
      return new NewsPage();
   }

   @Step(value = "Проверяем тест добавленной вкладки")
   public NewsPage checkTextTab(Tabs textTab) {
      String text = textTab.getTextTab();
      String locator = " //section/p[text()='" + text + "']";
      if (!waitElementExist(By.xpath(locator)))
         new AutotestError("Текст: " + text + " для новой вкладке не отображается на странице. Не найден элемент по локатору: " + locator);
      return new NewsPage();
   }

   @Step(value = "Проверяем порядок отображения вкладок")
   public NewsPage chechOrderTabs(List<Tabs> allTabs) {
      int size = allTabs.size();
      for (int i = 1, count = 0; i <= size; i++, count++) {
         String text = waitEnableElement(By.xpath("(//*[@class='common_r-padd']//li/a)[" + i + "]")).getText();
         if (!allTabs.get(count).getNameTab().equals(text))
            new AutotestError("Порядок вкладок на странице не совпадает с ожидаемым");
      }
      return this;
   }
}
