package Pages.CreateNewNews;

import DriverBuilder.Driver;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import static Helper.Elements.click;
import static Helper.Elements.waitEnableElement;
import static Helper.Helper.getStorage;

public class EventTab extends Menu {

   @FindBy(xpath = "(//label[text()='Тип события']/following::div[@class='multiselect'])[1]")
   private WebElement typeEvent;

   @FindBy(xpath = "(//label[text()='Место события']/following::div[@class='multiselect'])[1]")
   private WebElement placeEvent;

   @FindBy(xpath = "(//label[text()='Дата события']/following::input)[1]")
   private WebElement dateEvent;

   public EventTab() {
      PageFactory.initElements(Driver.getWebDriver(), this);
      waitEnableElement(typeEvent);
   }

   @Step(value = "Заполняем поле Тип события")
   public EventTab sentTypeEvent(String typeEventTxt) {
      click(typeEvent);
      click(By.xpath("//*[text()='" + typeEventTxt + "']"));
      return this;
   }

   @Step
   public EventTab sentPlaceEvent(String placeEventTxt) {
      click(placeEvent);
      click(By.xpath("//*[text()='" + placeEventTxt + "']"));
      return this;
   }

   @Step(value = "Заполняем поле Дата события текущим числом")
   public EventTab sentDateEvent() {
      DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy hh:mm");
      Date date = new Date();
      StringSelection stringSelection = new StringSelection(dateFormat.format(date));
      Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
      clipboard.setContents(stringSelection, null);
      click(dateEvent);
      Actions cpypast = new Actions(Driver.getWebDriver());
      //Windows
      //Action past = cpypast.sendKeys(dateEvent, Keys.CONTROL).sendKeys(dateEvent, "V").build();
      //Mac
      //Action past = cpypast.sendKeys(dateEvent, Keys.COMMAND).sendKeys(dateEvent, "V").build();
      Action past = (getStorage("os").equals("mac")) ?
            cpypast.sendKeys(dateEvent, Keys.COMMAND).sendKeys(dateEvent, "V").build() :
            cpypast.sendKeys(dateEvent, Keys.CONTROL).sendKeys(dateEvent, "V").build();
      past.perform();
      return this;
   }
}
