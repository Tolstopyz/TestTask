package Pages.CreateNewNews;

import DriverBuilder.Driver;
import Helper.Props;
import Pages.Content.ListMaterials;
import Pages.NewsPage;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static Helper.Elements.click;
import static Helper.Elements.waitEnableElement;

public class Menu {

   @FindBy(xpath = "//li[@class='nav-item']/a[contains(text(),'Вкладки')]")
   private WebElement buttonTabs;

   @FindBy(xpath = "//li[@class='nav-item']/a[contains(text(),'Основное')]")
   private WebElement buttonMain;

   @FindBy(xpath = "//li[@class='nav-item']/a[contains(text(),'Настройки страницы')]")
   private WebElement buttonPageSetting;

   @FindBy(xpath = "//li[@class='nav-item']/a[contains(text(),'Событие')]")
   private WebElement buttonEvent;

   @FindBy(xpath = "//li[@class='nav-item']/a[contains(text(),'SEO')]")
   private WebElement buttonSeo;

   @FindBy(xpath = "//li[@class='nav-item']/a[contains(text(),'Помогатель')]")
   private WebElement buttonHelper;

   @FindBy(xpath = "//div[text()='Данные введены неверно']")
   protected WebElement errorMessage;

   @FindBy(xpath = "(//button[@title='Удаляет страницу'])[1]")
   protected WebElement buttonDelete;

   @FindBy(xpath = "//button[@title='Удаляет страницу']//span[text()='Нажмите еще раз']")
   protected WebElement confermDelete;

   @FindBy(xpath = "//button[@class='btn btn-primary']/i[contains(@class,'fa-save')]")
   private WebElement buttonSave;

   @FindBy(xpath = "(//*[@id='wrapper']//a[@target='_blank'])[1]")
   private WebElement onSite;

   public Menu() {
      PageFactory.initElements(Driver.getWebDriver(), this);
      waitEnableElement(buttonTabs);
   }

   @Step(value = "Переходим на вкладку Вкладки")
   public TabsTab goToTabs() {
      click(buttonTabs);
      return new TabsTab();
   }

   @Step(value = "Нажимаем кнопку Сохранить")
   public Menu clickSave() {
      click(buttonSave);
      return new Menu();
   }

   @Step(value = "Нажимаем кнопку На сайте")
   public NewsPage clickOnSite() {
      click(onSite);
      return new NewsPage();
   }

   @Step(value = "Переходим на вкладку Основное")
   public MainTab goToMain() {
      click(buttonMain);
      return new MainTab();
   }

   @Step(value = "Переходим на вкладку Настройка страницы")
   public PageSettingTab goToPageSetting() {
      click(buttonPageSetting);
      return new PageSettingTab();
   }

   @Step(value = "Переходим на вкладку Событие")
   public EventTab goToEvent() {
      click(buttonEvent);
      return new EventTab();
   }

   @Step(value = "Переходим на вкладку SEO")
   public SEOTab goToSeo() {
      click(buttonSeo);
      return new SEOTab();
   }

   @Step(value = "Переходим на вкладку Помогатель")
   public HelperTab goToHelper() {
      click(buttonHelper);
      return new HelperTab();
   }

   @Step(value = "Переходим на вкладку Список материалов")
   public ListMaterials goToListMaterials() {
      click(By.xpath("//a[@href='/admin/materials']"));
      return new ListMaterials();
   }

   @Step(value = "Переходим на вкладку Список материалов")
   public ListMaterials goToListMaterialsByUrl() {
      Driver.getWebDriver().navigate().to("http://" + Props.getProperty("host") + "/admin/materials");
      return new ListMaterials();
   }

}
