package Pages.CreateNewNews;

import DriverBuilder.Driver;
import Exceptions.AutotestError;
import io.qameta.allure.Step;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static Helper.Elements.sendText;
import static Helper.Elements.waitEnableElement;
import static Helper.Helper.getNameValue;

public class PageSettingTab extends Menu {

   @FindBy(xpath = "//*[@class='form-group']//input[@placeholder='Укажите URL страницы']")
   private WebElement url;

   @FindBy(xpath = "//*[@class='form-group']//textarea[@placeholder='//*[@class='form-group']//input[@placeholder='Укажите ссылку в формате: http://site.ru']']")
   private WebElement externalLink;

   @FindBy(xpath = "//input[@placeholder='Укажите URL страницы']//following::small[text()='Поле обязательно для заполнения']")
   private WebElement requiredUrl;

   public PageSettingTab() {
      PageFactory.initElements(Driver.getWebDriver(), this);
      waitEnableElement(url);
   }

   @Step(value = "Заполняем поле URL")
   public PageSettingTab sentUrl(String urlText) {
      sendText(url, urlText);
      return this;
   }

   @Step
   public PageSettingTab sentExternalLink(String externalLinkText) {
      sendText(externalLink, externalLinkText);
      return this;
   }

   @Step(value = "Преверяем поле URL")
   public PageSettingTab checkUrl(String urlText) {
      String currentValue = getNameValue(url);
      if (!urlText.equals(currentValue)) {
         new AutotestError("Значение поля URL на вкладке Настройка страницы не совпадает с полем Заголовок на вкладке Основное");
      }
      return this;
   }

   @Step(value = "Преверяем, что появляются ошибка при сохранении")
   public PageSettingTab checkErrorUrlField() {
      waitEnableElement(errorMessage, "Сообщение 'Данные введены неверно' не появилось");
      waitEnableElement(requiredUrl, "Ошибка для поля 'URL' не возникла, новость без заполнения поля 'URL' создалась");
      return this;
   }

}
