package DriverBuilder;

import org.openqa.selenium.WebDriver;

public interface IWebDriverBuilder {
/*
    WebDriver GetDriver();
*/
}
