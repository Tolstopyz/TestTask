package Exceptions;

import Helper.ScreenShooter;
import org.apache.log4j.Logger;
import org.testng.Assert;

public class AutotestError {
   private static final Logger LOG = Logger.getLogger(AutotestError.class);

   public AutotestError(String msg) {
      LOG.error("AutotestError: " + msg);
      ScreenShooter.capturingFullPage();
      Assert.fail(msg);
   }

}
