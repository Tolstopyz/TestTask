package Helper;

import org.apache.log4j.Logger;
import org.testng.Assert;

import java.io.*;
import java.util.Properties;

public class Props {
    private static Props instance;
    private static Properties props;
    private static final Logger LOG = Logger.getLogger(Props.class);
    private String encoding = "UTF-8";
    private String pathToFileProp = "./src/main/resources/test.properties";


    public static Props getInstance() {
        if (instance == null) {
            instance = new Props();
        }
        return instance;
    }

    static {
        props = new Properties();
    }

    private Props() {
        LOG.info("Вычитываем все свойства из файла: " + pathToFileProp);
        try (InputStream inputStream = new FileInputStream(pathToFileProp);
             Reader reader = new InputStreamReader(inputStream, encoding)) {
            props.load(reader);
        } catch (FileNotFoundException ex) {
            Assert.fail("Невозможно найти файл по пути: " + pathToFileProp);
        } catch (IOException ex) {
            Assert.fail("Ошибки при чтения файла свойств: " + ex);
        }
    }

    public static Properties getProps() {
        return props;
    }

    public static String getProperty(String propsName) {
        LOG.info("Вычитываем из конфига значение для переменной: " + propsName);
        if (!getInstance().getProps().containsKey(propsName)) {
            Assert.fail("Свойства с именем " + propsName + " не задано в test.properties");
        }
        return getInstance().getProps().getProperty(propsName).trim();
    }
}
