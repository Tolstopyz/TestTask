package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import Pages.CreateNewNews.MainTab;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static Helper.Helper.closeTabAndSwitchMainWindow;
import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.afterOtherTests;

public class DeleteNewsGoBasket extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   @Test(description = "После удаления новость переноситься в корзину")
   public void deleteNews() {
      LOG.info("***** Запускаем тест После удаления новость переноситься в корзину *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            clickSave().
            clickOnSite().
            checkCorrectBodyTitle(testNews);
      closeTabAndSwitchMainWindow();
      new MainTab().
            goToListMaterials().
            deleteNews(testNews).
            goToBasket().
            clickRemovedMaterials().
            checkNewsExistinBasket(testNews);
   }

   @AfterMethod
   public void after() {
      afterOtherTests();
   }
}
