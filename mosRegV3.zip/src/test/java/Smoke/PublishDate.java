package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.deleteNewsWithoutClose;

public class PublishDate extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   @Test(description = "Поле Дата публикации заполняется автоматически про сохранении новости")
   public void date() {
      LOG.info("***** Запускаем тест Поле Дата публикации заполняется автоматически про сохранении новости *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            clickSave().
            goToMain().
            checkFieldDate();
   }

   @AfterTest
   public void deleteCreatedNews() {
      deleteNewsWithoutClose(testNews);
   }
}
