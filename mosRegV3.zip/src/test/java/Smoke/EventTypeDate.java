package Smoke;

import Objects.News;
import Pages.Authorization.AuthorizationPage;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.deleteNewsWithoutClose;

public class EventTypeDate extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   private String result = "Главная / Сейчас в работе / Мероприятия / Прием граждан";

   @Test(description = "При заполнении поля Дата события И Тип события Прием граждан появляется пункт Главная / Сейчас в работе / Мероприятия / Прием граждан")
   public void addTypeEvent() {
      LOG.info("***** Запускаем тест При заполнении поля Дата события И Тип события Прием граждан появляется пункт Главная / Сейчас в работе / Мероприятия / Прием граждан *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            goToEvent().
            sentDateEvent().
            sentTypeEvent("Прием граждан").
            clickSave().
            goToMain().
            checkFieldItemsMenu(result);
   }

   @AfterTest
   public void after() {
      deleteNewsWithoutClose(testNews);
   }

}
