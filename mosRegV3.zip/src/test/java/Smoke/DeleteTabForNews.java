package Smoke;

import Objects.News;
import Objects.Tabs;
import Pages.Authorization.AuthorizationPage;
import Pages.CreateNewNews.TabsTab;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

import static Helper.Helper.closeTabAndSwitchMainWindow;
import static Helper.Helper.getRandomHeadline;
import static Smoke.AfterTests.closePage;
import static Smoke.AfterTests.deleteNews;

public class DeleteTabForNews extends BaseTests {

   private News testNews = new News(
         getRandomHeadline(),
         "Опубликовано");

   private Tabs firstTabs = new Tabs(
         "Первая вкладка",
         "Текст для первой вкладки");

   private Tabs secondTabs = new Tabs(
         "Вторая вкладка",
         "Текст для второй вкладки");

   private List<Tabs> allTabs = Arrays.asList(firstTabs, secondTabs);

   @Test(description = "Удаление ранее созданной вкладки у новой новости")
   public void addNewTab() throws InterruptedException {
      LOG.info("***** Запускаем тест Удаление ранее созданной вкладки у новой новости *****");
      new AuthorizationPage().
            login().
            createNews().
            createNewNews(testNews).
            goToTabs().
            addSeveralTabs(allTabs).
            clickSave().
            clickOnSite().
            checkBodyTitle(testNews).
            checkTabsAndText(allTabs);
      closeTabAndSwitchMainWindow();
      new TabsTab().
            deleteTab(firstTabs).
            clickSave().
            clickOnSite().
            checkBodyTitle(testNews).
            checkTab(secondTabs);
   }

   @AfterMethod
   public void after() {
      deleteNews(testNews);
   }
}
