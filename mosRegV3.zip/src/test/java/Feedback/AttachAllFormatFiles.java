package Feedback;

import DriverBuilder.Driver;
import Pages.Feedback;
import Smoke.BaseTests;
import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static Smoke.AfterTests.afterOtherTests;

public class AttachAllFormatFiles {

    protected static final Logger LOG = Logger.getLogger(BaseTests.class);

    @DataProvider(name = "TypeOfFiles")
    public static Object[][] getClient1Data() {
        return new Object[][]{
                {"file033.txt"},
                {"file034.doc"},
                {"file035.docx"},
                {"file036.rtf"},
                {"file037.xls"},
                {"file038.xlsx"},
                {"file039.pps"},
                {"file040.ppt"},
                {"file041.odt"},
                {"file042.ods"},
                {"file043.odp"},
                {"file044.pub"},
                {"file045.pdf"},
                {"file046.jpg"},
                {"file047.jpeg"},
                {"file048.bmp"},
                {"file049.png"},
                {"file050.tif"},
                {"file051.gif"},
                {"file052.pcx"},
                {"file053.mp3"},
                {"file054.wma"},
                {"file055.avi"},
                {"file056.mp4"},
                {"file057.mkv"},
                {"file058.wmv"},
                {"file059.mov"},
                {"file060.flv"}
        };
    }

    @Test(dataProvider = "TypeOfFiles", description = "Пользоватль прикрепляет файл всех доступных форматов")
    public void attachAllTypeFile(String nameFile) {
        LOG.info("***** Пользоватль прикрепляет файл всех доступных форматов *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .attachFile(nameFile)
                .errorMessageAttachNoExist();
    }

    @AfterMethod
    public void after() {
        afterOtherTests();
    }

    @BeforeMethod()
    public void before() {
        Driver.getWebDriver().navigate().to("http://guip:guip@ui.mosreg.aismo.ru/feedback#step1");
    }
}
