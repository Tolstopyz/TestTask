package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckLengthNameCoAuthor extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет поле соавтор Имя менее 2х символов")
    public void addFeedbackWithoutEmail() {
        LOG.info("***** Пользоватль заполняет поле соавтор Имя менее 2х символов *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonAddCoAuthor()
                .sentCoAuthorName("А")
                .sentCoAuthorSurname("Иванов")
                .clickButtonSent()
                .checkErrorLengthCoAuthorName();
    }
}
