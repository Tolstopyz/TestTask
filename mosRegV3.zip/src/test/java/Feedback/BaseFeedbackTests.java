package Feedback;

import DriverBuilder.Driver;
import Smoke.BaseTests;
import org.apache.log4j.Logger;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import static Smoke.AfterTests.afterOtherTests;

public class BaseFeedbackTests {

    protected static final Logger LOG = Logger.getLogger(BaseTests.class);

    @BeforeTest()
    public void before() {
        Driver.getWebDriver().navigate().to("http://guip:guip@ui.mosreg.aismo.ru/feedback#step1");
    }

    @AfterTest
    public void after() {
        afterOtherTests();
    }
}
