package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class CheckFullFormDeleteCoAuthor extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет все поля и удаляет ранее добавленных соавторов")
    public void addFeedbackWithoutAppealText() {
        LOG.info("***** Пользоватль заполняет все поля и удаляет ранее добавленных соавторов *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentMiddleName("Иванович")
                .sentNameCompany("Газпром")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentPhoneNumber("+79211111111")
                .sentAppealText("Текст обращения от Антона")
                .clickButtonAddCoAuthor()
                .sentCoAuthorName("Артем")
                .sentCoAuthorSurname("Иванов")
                .sentCoAuthorEmail("mail@mail.com")
                .clickButtonAddCoAuthor()
                .sentCoAuthor2Name("Иван")
                .sentCoAuthor2Surname("Петров")
                .sentCoAuthor2MiddleName("Сергеевич")
                .sentCoAuthor2Email("mail@mail.com")
                .delete2CoAuthor()
                .sentCapchaText("Текст Капча")
                .clickButtonSent()
                .errorMessageСapchaError();
    }

}
