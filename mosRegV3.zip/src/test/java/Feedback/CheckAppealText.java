package Feedback;

import Pages.Feedback;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Smoke.AfterTests.afterOtherTests;

public class CheckAppealText extends BaseFeedbackTests {
    @Test(description = "Пользоватль заполняет все обязательные поля кроме Текста обращения")
    public void addFeedbackWithoutAppealText() {
        LOG.info("***** Пользоватль заполняет все поля кроме Текста обращения *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .clickButtonSent()
                .checkErrorAppealText();
    }

    @AfterTest
    public void after() {
        afterOtherTests();
    }
}
