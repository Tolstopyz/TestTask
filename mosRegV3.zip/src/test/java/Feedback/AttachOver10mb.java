package Feedback;

import Pages.Feedback;
import org.testng.annotations.Test;

public class AttachOver10mb extends BaseFeedbackTests {
    @Test(description = "Пользоватль прикрепляет файлы более 10 mb")
    public void attachBigFile() {
        LOG.info("***** Пользоватль прикрепляет файлы более 10 mb *****");
        new Feedback()
                .sentName("Антон")
                .sentSurname("Петров")
                .sentEmail("anton@mail.ru")
                .sentReplayEmail("anton@mail.ru")
                .sentAppealText("Текст обращения от Антона")
                .attachFile("test10mb.txt")
                .clickButtonSent()
                .checkErrorBigFile();
    }
}
